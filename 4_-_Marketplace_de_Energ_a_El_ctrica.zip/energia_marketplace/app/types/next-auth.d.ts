
import NextAuth from "next-auth"

declare module "next-auth" {
  interface Session {
    user: {
      id: string
      email: string
      name?: string
      userType: string
      companyName?: string
      isKycVerified: boolean
    }
  }

  interface User {
    id: string
    email: string
    name?: string
    userType: string
    companyName?: string
    isKycVerified: boolean
  }

  interface JWT {
    userType: string
    companyName?: string
    isKycVerified: boolean
  }
}
