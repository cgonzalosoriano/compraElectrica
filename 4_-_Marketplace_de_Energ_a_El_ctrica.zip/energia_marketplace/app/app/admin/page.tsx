
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { PrismaClient } from '@prisma/client'
import AdminDashboard from '@/components/admin/admin-dashboard'

const prisma = new PrismaClient()

export default async function AdminPage() {
  const session = await getServerSession(authOptions)
  
  if (!session) {
    redirect('/auth/signin')
  }

  if (session.user.userType !== 'ADMIN') {
    redirect('/')
  }

  // Obtener estadísticas del marketplace
  const stats = await Promise.all([
    prisma.user.count({ where: { userType: 'CLIENT' } }),
    prisma.user.count({ where: { userType: 'PROVIDER' } }),
    prisma.offer.count({ where: { status: 'ACTIVE' } }),
    prisma.transaction.count(),
    prisma.transaction.aggregate({
      _sum: { totalAmount: true }
    }),
    prisma.commission.aggregate({
      _sum: { amount: true }
    })
  ])

  // Obtener transacciones recientes
  const recentTransactions = await prisma.transaction.findMany({
    include: {
      client: true,
      offer: {
        include: {
          provider: true
        }
      }
    },
    orderBy: { createdAt: 'desc' },
    take: 10
  })

  // Obtener disputas
  const disputes = await prisma.dispute.findMany({
    include: {
      transaction: {
        include: {
          client: true,
          offer: {
            include: {
              provider: true
            }
          }
        }
      },
      initiator: true
    },
    orderBy: { createdAt: 'desc' }
  })

  const dashboardData = {
    stats: {
      clients: stats[0],
      providers: stats[1],
      activeOffers: stats[2],
      totalTransactions: stats[3],
      totalVolume: stats[4]._sum.totalAmount || 0,
      totalCommissions: stats[5]._sum.amount || 0
    },
    recentTransactions,
    disputes
  }

  return <AdminDashboard data={dashboardData} />
}
