
import { NextRequest, NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import bcrypt from "bcryptjs"

export const dynamic = "force-dynamic"

const prisma = new PrismaClient()

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { 
      email, 
      password, 
      name, 
      companyName, 
      phone, 
      userType, 
      cuit,
      // Campos adicionales para clientes
      distributorName,
      region,
      tariffType,
      contractedPower,
      userNumber,
      address,
      city,
      province
    } = body

    // Verificar si el usuario ya existe
    const existingUser = await prisma.user.findUnique({
      where: { email }
    })

    if (existingUser) {
      return NextResponse.json(
        { error: "Ya existe un usuario con este email" },
        { status: 400 }
      )
    }

    // Verificar CUIT único si se proporciona
    if (cuit) {
      const existingCuit = await prisma.user.findUnique({
        where: { cuit }
      })
      
      if (existingCuit) {
        return NextResponse.json(
          { error: "Ya existe un usuario con este CUIT" },
          { status: 400 }
        )
      }
    }

    // Hash de la contraseña
    const hashedPassword = await bcrypt.hash(password, 10)

    // Validar y normalizar userType
    const normalizedUserType = userType ? userType.toUpperCase() : 'CLIENT'
    if (!['CLIENT', 'PROVIDER', 'ADMIN'].includes(normalizedUserType)) {
      return NextResponse.json(
        { error: "Tipo de usuario inválido" },
        { status: 400 }
      )
    }

    // Crear usuario
    const user = await prisma.user.create({
      data: {
        email,
        password: hashedPassword,
        name,
        companyName,
        phone,
        userType: normalizedUserType,
        cuit,
        distributorName,
        region,
        tariffType,
        contractedPower: contractedPower ? parseFloat(contractedPower) : null,
        userNumber,
        address,
        city,
        province
      }
    })

    // No devolver la contraseña
    const { password: _, ...userWithoutPassword } = user

    return NextResponse.json(
      { user: userWithoutPassword, message: "Usuario creado exitosamente" },
      { status: 201 }
    )
  } catch (error) {
    console.error("Error en registro:", error)
    return NextResponse.json(
      { error: "Error interno del servidor" },
      { status: 500 }
    )
  }
}
