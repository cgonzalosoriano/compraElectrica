
import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { PrismaClient } from "@prisma/client"

export const dynamic = "force-dynamic"

const prisma = new PrismaClient()

export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session) {
      return NextResponse.json(
        { error: "No autorizado" },
        { status: 401 }
      )
    }

    const body = await request.json()
    const {
      name,
      companyName,
      phone,
      address,
      city,
      province,
      postalCode,
      distributorName,
      region,
      tariffType,
      contractedPower,
      userNumber
    } = body

    const updatedUser = await prisma.user.update({
      where: { id: session.user.id },
      data: {
        name,
        companyName,
        phone,
        address,
        city,
        province,
        postalCode,
        distributorName,
        region,
        tariffType,
        contractedPower: contractedPower ? parseFloat(contractedPower) : null,
        userNumber
      }
    })

    // No devolver la contraseña
    const { password: _, ...userWithoutPassword } = updatedUser

    return NextResponse.json(
      { 
        user: userWithoutPassword,
        message: "Perfil actualizado exitosamente"
      }
    )
  } catch (error) {
    console.error("Error al actualizar perfil:", error)
    return NextResponse.json(
      { error: "Error interno del servidor" },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session) {
      return NextResponse.json(
        { error: "No autorizado" },
        { status: 401 }
      )
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id }
    })

    if (!user) {
      return NextResponse.json(
        { error: "Usuario no encontrado" },
        { status: 404 }
      )
    }

    // No devolver la contraseña
    const { password: _, ...userWithoutPassword } = user

    return NextResponse.json({ user: userWithoutPassword })
  } catch (error) {
    console.error("Error al obtener perfil:", error)
    return NextResponse.json(
      { error: "Error interno del servidor" },
      { status: 500 }
    )
  }
}
