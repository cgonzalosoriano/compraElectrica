
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { uploadFile } from '@/lib/s3';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const formData = await request.formData();
    const file = formData.get('file') as File;
    const contractId = formData.get('contractId') as string;
    const userType = formData.get('userType') as string;

    if (!file || !contractId || !userType) {
      return NextResponse.json({ error: 'Faltan datos requeridos' }, { status: 400 });
    }

    // Convertir File a Buffer
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    // Generar nombre único para el archivo
    const timestamp = Date.now();
    const fileName = `signed-contracts/${contractId}/${userType.toLowerCase()}-${timestamp}.pdf`;

    // Subir a S3
    const cloudStoragePath = await uploadFile(buffer, fileName);

    return NextResponse.json({
      cloudStoragePath,
      message: 'Archivo subido exitosamente'
    });

  } catch (error) {
    console.error('Error uploading signed contract:', error);
    return NextResponse.json(
      { error: 'Error al subir el archivo: ' + (error as Error).message },
      { status: 500 }
    );
  }
}
