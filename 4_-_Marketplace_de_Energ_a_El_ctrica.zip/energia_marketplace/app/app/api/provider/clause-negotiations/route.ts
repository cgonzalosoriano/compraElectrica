
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || session.user.userType !== 'PROVIDER') {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    // Obtener todas las negociaciones de cláusulas para las ofertas del proveedor
    const negotiations = await prisma.clauseNegotiation.findMany({
      where: {
        clientOffer: {
          offer: {
            providerId: session.user.id
          }
        },
        status: {
          in: ['NEGOTIATING', 'AGREED', 'REJECTED'] // Estados que el proveedor puede ver
        }
      },
      include: {
        clientOffer: {
          include: {
            client: {
              select: {
                id: true,
                name: true,
                email: true,
                companyName: true
              }
            },
            offer: {
              select: {
                id: true,
                generationSource: true,
                deliveryNode: true
              }
            }
          }
        }
      },
      orderBy: [
        {
          status: 'asc' // Mostrar primero las pendientes (NEGOTIATING)
        },
        {
          updatedAt: 'desc'
        }
      ]
    })

    return NextResponse.json({ 
      success: true,
      negotiations
    })

  } catch (error) {
    console.error('Error fetching provider negotiations:', error)
    return NextResponse.json({ 
      error: 'Error interno del servidor' 
    }, { status: 500 })
  }
}
