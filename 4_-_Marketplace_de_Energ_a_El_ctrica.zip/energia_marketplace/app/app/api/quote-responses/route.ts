
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Obtener las respuestas del proveedor
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.userType !== 'PROVIDER') {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const responses = await prisma.quoteResponse.findMany({
      where: {
        providerId: session.user.id,
      },
      include: {
        quoteRequest: {
          include: {
            client: {
              select: {
                id: true,
                name: true,
                companyName: true,
                email: true,
              },
            },
            periods: { orderBy: { periodNumber: 'asc' } },
            clauses: true,
          },
        },
        periods: { orderBy: { periodNumber: 'asc' } },
        clauseResponses: true,
        review: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ responses });
  } catch (error) {
    console.error('Error al obtener respuestas:', error);
    return NextResponse.json(
      { error: 'Error al obtener las respuestas' },
      { status: 500 }
    );
  }
}

// Crear una nueva respuesta
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.userType !== 'PROVIDER') {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const {
      quoteRequestId,
      energyPricePerMWh,
      powerPricePerKW,
      paymentTerms,
      guaranteesRequired,
      deliveryNode,
      generationSource,
      otherConditions,
      totalEstimated,
      providerComments,
      periods,
      clauseResponses,
    } = body;

    // Verificar que la solicitud existe y está activa
    const quoteRequest = await prisma.quoteRequest.findUnique({
      where: { id: quoteRequestId },
    });

    if (!quoteRequest) {
      return NextResponse.json(
        { error: 'Solicitud no encontrada' },
        { status: 404 }
      );
    }

    if (quoteRequest.status !== 'ACTIVE') {
      return NextResponse.json(
        { error: 'Esta solicitud ya no está activa' },
        { status: 400 }
      );
    }

    // Verificar que el proveedor no haya respondido ya
    const existingResponse = await prisma.quoteResponse.findUnique({
      where: {
        quoteRequestId_providerId: {
          quoteRequestId,
          providerId: session.user.id,
        },
      },
    });

    if (existingResponse) {
      return NextResponse.json(
        { error: 'Ya has respondido a esta solicitud' },
        { status: 400 }
      );
    }

    // Crear la respuesta
    const response = await prisma.quoteResponse.create({
      data: {
        quoteRequestId,
        providerId: session.user.id,
        energyPricePerMWh: parseFloat(energyPricePerMWh),
        powerPricePerKW: parseFloat(powerPricePerKW),
        paymentTerms,
        guaranteesRequired,
        deliveryNode,
        generationSource,
        otherConditions,
        totalEstimated: totalEstimated ? parseFloat(totalEstimated) : null,
        providerComments,
        status: 'SUBMITTED',
      },
    });

    // Crear períodos si se proporcionaron
    if (periods && periods.length > 0) {
      await prisma.quoteResponsePeriod.createMany({
        data: periods.map((p: any, index: number) => ({
          quoteResponseId: response.id,
          periodNumber: index + 1,
          periodName: p.periodName,
          energyPricePerMWh: p.energyPricePerMWh ? parseFloat(p.energyPricePerMWh) : null,
          powerPricePerKW: p.powerPricePerKW ? parseFloat(p.powerPricePerKW) : null,
          availablePowerKW: p.availablePowerKW ? parseFloat(p.availablePowerKW) : null,
          availableEnergyMWh: p.availableEnergyMWh ? parseFloat(p.availableEnergyMWh) : null,
        })),
      });
    }

    // Crear respuestas a cláusulas si se proporcionaron
    if (clauseResponses && clauseResponses.length > 0) {
      await prisma.quoteResponseClause.createMany({
        data: clauseResponses.map((c: any) => ({
          quoteResponseId: response.id,
          clauseId: c.clauseId,
          action: c.action,
          negotiation: c.negotiation || null,
        })),
      });
    }

    // Crear notificación para el cliente
    await prisma.notification.create({
      data: {
        userId: quoteRequest.clientId,
        type: 'NEW_QUOTE_RESPONSE',
        title: 'Nueva oferta recibida',
        message: `Has recibido una nueva oferta para "${quoteRequest.title}".`,
        quoteRequestId,
        quoteResponseId: response.id,
      },
    });

    return NextResponse.json({
      message: 'Oferta enviada exitosamente',
      response,
    });
  } catch (error) {
    console.error('Error al crear respuesta:', error);
    return NextResponse.json(
      { error: 'Error al enviar la oferta' },
      { status: 500 }
    );
  }
}

// Actualizar una respuesta existente
export async function PATCH(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.userType !== 'PROVIDER') {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const {
      responseId,
      energyPricePerMWh,
      powerPricePerKW,
      paymentTerms,
      guaranteesRequired,
      deliveryNode,
      generationSource,
      otherConditions,
      totalEstimated,
      providerComments,
      clauseResponses,
    } = body;

    // Verificar que la respuesta existe y pertenece al proveedor
    const existingResponse = await prisma.quoteResponse.findUnique({
      where: { id: responseId },
      include: {
        quoteRequest: true,
        clauseResponses: true,
      },
    });

    if (!existingResponse) {
      return NextResponse.json(
        { error: 'Respuesta no encontrada' },
        { status: 404 }
      );
    }

    if (existingResponse.providerId !== session.user.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 403 }
      );
    }

    // Verificar que el cliente no haya visto la oferta
    if (existingResponse.viewedByClient) {
      return NextResponse.json(
        { error: 'No puedes editar una oferta que ya fue vista por el cliente' },
        { status: 400 }
      );
    }

    // Actualizar la respuesta
    const updatedResponse = await prisma.quoteResponse.update({
      where: { id: responseId },
      data: {
        energyPricePerMWh: parseFloat(energyPricePerMWh),
        powerPricePerKW: parseFloat(powerPricePerKW),
        paymentTerms,
        guaranteesRequired,
        deliveryNode,
        generationSource,
        otherConditions,
        totalEstimated: totalEstimated ? parseFloat(totalEstimated) : null,
        providerComments,
        updatedAt: new Date(),
      },
    });

    // Eliminar las respuestas de cláusulas anteriores
    await prisma.quoteResponseClause.deleteMany({
      where: { quoteResponseId: responseId },
    });

    // Crear las nuevas respuestas a cláusulas
    if (clauseResponses && clauseResponses.length > 0) {
      await prisma.quoteResponseClause.createMany({
        data: clauseResponses.map((c: any) => ({
          quoteResponseId: responseId,
          clauseId: c.clauseId,
          action: c.action,
          negotiation: c.negotiation || null,
        })),
      });
    }

    return NextResponse.json({
      message: 'Oferta actualizada exitosamente',
      response: updatedResponse,
    });
  } catch (error) {
    console.error('Error al actualizar respuesta:', error);
    return NextResponse.json(
      { error: 'Error al actualizar la oferta' },
      { status: 500 }
    );
  }
}
