
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;
    const body = await request.json();
    const { message, clientId, providerId } = body;

    if (!message || !clientId || !providerId) {
      return NextResponse.json(
        { error: 'Faltan datos requeridos' },
        { status: 400 }
      );
    }

    // Obtener el quote response para tener más contexto
    const quoteResponse = await prisma.quoteResponse.findUnique({
      where: { id },
      include: {
        quoteRequest: {
          select: {
            title: true
          }
        }
      }
    });

    if (!quoteResponse) {
      return NextResponse.json(
        { error: 'Respuesta de cotización no encontrada' },
        { status: 404 }
      );
    }

    // Crear el mensaje
    const newMessage = await prisma.message.create({
      data: {
        senderId: clientId,
        recipientId: providerId,
        subject: `Consulta sobre oferta - ${quoteResponse.quoteRequest.title}`,
        content: message,
        isRead: false,
        messageType: 'NEGOTIATION'
      }
    });

    return NextResponse.json({
      success: true,
      message: 'Mensaje enviado exitosamente',
      messageId: newMessage.id
    });

  } catch (error) {
    console.error('Error sending message:', error);
    return NextResponse.json(
      { error: 'Error al enviar el mensaje' },
      { status: 500 }
    );
  }
}
