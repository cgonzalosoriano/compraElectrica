
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

// POST /api/quote-responses/[id]/award - Adjudicar una oferta
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user || user.userType !== 'CLIENT') {
      return NextResponse.json(
        { error: 'Solo los clientes pueden adjudicar ofertas' },
        { status: 403 }
      );
    }

    const quoteResponseId = params.id;

    // Verificar que la oferta existe y pertenece al cliente
    const quoteResponse = await prisma.quoteResponse.findUnique({
      where: { id: quoteResponseId },
      include: {
        quoteRequest: true,
        provider: true,
        review: true,
      },
    });

    if (!quoteResponse) {
      return NextResponse.json(
        { error: 'Oferta no encontrada' },
        { status: 404 }
      );
    }

    if (quoteResponse.quoteRequest.clientId !== user.id) {
      return NextResponse.json(
        { error: 'No autorizado para adjudicar esta oferta' },
        { status: 403 }
      );
    }

    // Verificar que todas las cláusulas han sido aceptadas
    if (!quoteResponse.review?.allClausesAccepted) {
      return NextResponse.json(
        { error: 'No se pueden adjudicar ofertas sin todas las cláusulas aceptadas' },
        { status: 400 }
      );
    }

    // Actualizar el estado de la oferta a ACCEPTED
    await prisma.quoteResponse.update({
      where: { id: quoteResponseId },
      data: {
        status: 'ACCEPTED',
      },
    });

    // Actualizar el estado de la solicitud de cotización a AWARDED
    await prisma.quoteRequest.update({
      where: { id: quoteResponse.quoteRequestId },
      data: {
        status: 'AWARDED',
      },
    });

    // Crear un contrato basado en esta respuesta de cotización
    const contract = await prisma.quoteContract.create({
      data: {
        quoteResponseId: quoteResponse.id,
        quoteRequestId: quoteResponse.quoteRequestId,
        clientId: user.id,
        providerId: quoteResponse.providerId,
        status: 'PENDING_SIGNATURE',
        terms: generateContractTerms(quoteResponse),
      },
    });

    // Crear notificación para el proveedor
    await prisma.notification.create({
      data: {
        userId: quoteResponse.providerId,
        type: 'QUOTE_RESPONSE_ACCEPTED',
        title: '¡Tu oferta fue adjudicada!',
        message: `El cliente ha adjudicado tu oferta para "${quoteResponse.quoteRequest.title}". Puedes proceder con la firma del contrato.`,
        quoteResponseId: quoteResponse.id,
        actionUrl: `/dashboard/provider?tab=contracts`,
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Oferta adjudicada exitosamente',
      contract: contract,
    });
  } catch (error) {
    console.error('Error al adjudicar oferta:', error);
    return NextResponse.json(
      { error: 'Error al adjudicar oferta' },
      { status: 500 }
    );
  }
}

// Función auxiliar para generar términos del contrato
function generateContractTerms(quoteResponse: any): string {
  const terms = [];

  terms.push(`CONTRATO DE SUMINISTRO DE ENERGÍA ELÉCTRICA`);
  terms.push(`\n`);
  terms.push(`Solicitud: ${quoteResponse.quoteRequest.title}`);
  terms.push(`Proveedor: ${quoteResponse.provider.companyName || quoteResponse.provider.name}`);
  terms.push(`\n`);
  terms.push(`CONDICIONES ACORDADAS:`);
  terms.push(`\n`);

  if (quoteResponse.energyPricePerMWh) {
    terms.push(`Precio Energía: $${quoteResponse.energyPricePerMWh}/MWh`);
  }

  if (quoteResponse.powerPricePerKW) {
    terms.push(`Precio Potencia: $${quoteResponse.powerPricePerKW}/kW-mes`);
  }

  if (quoteResponse.totalEstimated) {
    terms.push(`Total Estimado: $${quoteResponse.totalEstimated.toLocaleString('es-AR')}`);
  }

  if (quoteResponse.generationSource) {
    terms.push(`Fuente de Generación: ${quoteResponse.generationSource}`);
  }

  if (quoteResponse.paymentTerms) {
    terms.push(`Condiciones de Pago: ${quoteResponse.paymentTerms}`);
  }

  if (quoteResponse.guaranteesRequired) {
    terms.push(`Garantías: ${quoteResponse.guaranteesRequired}`);
  }

  if (quoteResponse.deliveryNode) {
    terms.push(`Nodo de Entrega: ${quoteResponse.deliveryNode}`);
  }

  if (quoteResponse.otherConditions) {
    terms.push(`\nOtras Condiciones: ${quoteResponse.otherConditions}`);
  }

  terms.push(`\n`);
  terms.push(`Plazo: ${quoteResponse.quoteRequest.termMonths} meses`);
  terms.push(`\n`);
  terms.push(`Todas las cláusulas han sido revisadas y aceptadas por ambas partes.`);

  return terms.join('\n');
}
