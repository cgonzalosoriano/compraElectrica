
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || !session.user) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { id } = params;

    // Obtener la respuesta de cotización
    const quoteResponse = await prisma.quoteResponse.findUnique({
      where: { id },
      include: {
        quoteRequest: true,
        review: true,
        clauseResponses: true,
        provider: true,
      },
    });

    if (!quoteResponse) {
      return NextResponse.json({ error: 'Oferta no encontrada' }, { status: 404 });
    }

    // Verificar que el usuario sea el cliente
    if (quoteResponse.quoteRequest.clientId !== session.user.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 403 });
    }

    // Verificar que todas las cláusulas estén aceptadas
    if (!quoteResponse.review?.allClausesAccepted) {
      return NextResponse.json(
        { error: 'Debes aceptar todas las cláusulas antes de aceptar la oferta' },
        { status: 400 }
      );
    }

    // Obtener información del cliente
    const client = await prisma.user.findUnique({
      where: { id: quoteResponse.quoteRequest.clientId },
    });

    if (!client) {
      return NextResponse.json({ error: 'Cliente no encontrado' }, { status: 404 });
    }

    // Calcular el volumen total solicitado
    const periods = await prisma.quoteRequestPeriod.findMany({
      where: { quoteRequestId: quoteResponse.quoteRequestId },
    });

    const totalEnergy = periods.reduce((sum, p) => sum + (p.energyMWh || 0), 0);

    // Actualizar el estado de la respuesta a ACCEPTED
    await prisma.quoteResponse.update({
      where: { id },
      data: {
        status: 'ACCEPTED',
        viewedByClient: true,
      },
    });

    // Actualizar el estado de la solicitud a AWARDED
    await prisma.quoteRequest.update({
      where: { id: quoteResponse.quoteRequestId },
      data: {
        status: 'AWARDED',
      },
    });

    // Crear QuoteContract (Circuito 2 - independiente del Circuito 1)
    const quoteContract = await prisma.quoteContract.create({
      data: {
        quoteResponseId: id,
        quoteRequestId: quoteResponse.quoteRequestId,
        clientId: quoteResponse.quoteRequest.clientId,
        providerId: quoteResponse.providerId,
        status: 'PENDING_SIGNATURE',
        terms: `CONTRATO DE SUMINISTRO DE ENERGÍA ELÉCTRICA
(Generado desde Solicitud de Cotización)

FECHA: ${new Date().toLocaleDateString('es-AR')}

=====================================================
INFORMACIÓN DE LAS PARTES
=====================================================

PROVEEDOR: ${quoteResponse.provider?.companyName || quoteResponse.provider?.name}
CUIT: ${quoteResponse.provider?.cuit || 'N/A'}
Email: ${quoteResponse.provider?.email}
Teléfono: ${quoteResponse.provider?.phone || 'N/A'}

CLIENTE: ${client.companyName || client.name}
CUIT: ${client.cuit || 'N/A'}
Email: ${client.email}
Teléfono: ${client.phone || 'N/A'}

=====================================================
TÉRMINOS DEL CONTRATO
=====================================================

SOLICITUD ORIGINAL: ${quoteResponse.quoteRequest.title}
${quoteResponse.quoteRequest.description ? '\nDescripción: ' + quoteResponse.quoteRequest.description : ''}

PRECIOS ACORDADOS:
- Precio Energía: $${quoteResponse.energyPricePerMWh}/MWh
- Precio Potencia: $${quoteResponse.powerPricePerKW}/kW-mes

VOLÚMENES:
- Volumen Total: ${totalEnergy.toFixed(2)} MWh
- Plazo: ${quoteResponse.quoteRequest.termMonths} meses

CARACTERÍSTICAS DEL SUMINISTRO:
- Fuente de Generación: ${quoteResponse.generationSource || 'No especificada'}
- Nodo de Entrega: ${quoteResponse.deliveryNode || quoteResponse.quoteRequest.deliveryNode || 'No especificado'}

CONDICIONES:
- Condiciones de Pago: ${quoteResponse.paymentTerms || quoteResponse.quoteRequest.paymentTerms || 'No especificadas'}
- Garantías Requeridas: ${quoteResponse.guaranteesRequired || quoteResponse.quoteRequest.guaranteesOffered || 'No especificadas'}
${quoteResponse.otherConditions ? '- Otras Condiciones: ' + quoteResponse.otherConditions : ''}

INFORMACIÓN DEL CLIENTE:
- Número de Usuario: ${quoteResponse.quoteRequest.userNumber || client.userNumber || 'N/A'}
- Distribuidora: ${quoteResponse.quoteRequest.distributorName || client.distributorName || 'N/A'}
- Región: ${quoteResponse.quoteRequest.region || client.region || 'N/A'}

TOTAL ESTIMADO: $${quoteResponse.totalEstimated?.toFixed(2) || 'A calcular'}

=====================================================
FIRMAS
=====================================================

Este contrato requiere la firma digital de ambas partes para ser válido.

Estado: PENDIENTE DE FIRMA`,
      },
    });

    // Notificar al proveedor
    await prisma.notification.create({
      data: {
        userId: quoteResponse.providerId,
        type: 'QUOTE_RESPONSE_ACCEPTED',
        title: '¡Tu oferta fue aceptada!',
        message: `El cliente ha aceptado tu oferta para "${quoteResponse.quoteRequest.title}". Ahora puedes proceder a firmar el contrato en la sección de Contratos.`,
        quoteResponseId: id,
      },
    });

    return NextResponse.json({ 
      success: true,
      message: 'Oferta aceptada exitosamente. El contrato está listo para firma.',
      quoteContractId: quoteContract.id,
    });
  } catch (error) {
    console.error('Error al aceptar oferta:', error);
    return NextResponse.json(
      { error: 'Error al aceptar oferta' },
      { status: 500 }
    );
  }
}
