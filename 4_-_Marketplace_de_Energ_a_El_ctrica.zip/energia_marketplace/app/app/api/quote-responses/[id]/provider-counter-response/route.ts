
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || !session.user) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { id } = params;
    const { providerActions } = await request.json();

    // Obtener la respuesta de cotización
    const quoteResponse = await prisma.quoteResponse.findUnique({
      where: { id },
      include: {
        quoteRequest: true,
        clauseResponses: true,
        provider: true,
      },
    });

    if (!quoteResponse) {
      return NextResponse.json({ error: 'Oferta no encontrada' }, { status: 404 });
    }

    // Verificar que el usuario sea el proveedor
    if (quoteResponse.providerId !== session.user.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 403 });
    }

    // Actualizar o crear registros para cada cláusula con la respuesta del proveedor
    const updates = Object.entries(providerActions).map(async ([clauseId, action]: [string, any]) => {
      // Verificar si es una cláusula estándar
      const isStandardClause = clauseId.startsWith('energy-price-') || 
                               clauseId.startsWith('power-price-') || 
                               clauseId.startsWith('term-months-') ||
                               clauseId.startsWith('payment-terms-') ||
                               clauseId.startsWith('guarantees-') ||
                               clauseId.startsWith('energy-source-') ||
                               clauseId.startsWith('delivery-node-');

      if (isStandardClause) {
        // Para cláusulas estándar, usar upsert
        return prisma.quoteResponseClause.upsert({
          where: { 
            id: clauseId,
          },
          create: {
            id: clauseId,
            quoteResponseId: id,
            clauseId: clauseId,
            action: 'NEGOTIATE',
            negotiation: null,
            providerCounterAction: action.action,
            providerCounterNegotiation: action.negotiation || null,
            providerCounterDate: new Date(),
          },
          update: {
            providerCounterAction: action.action,
            providerCounterNegotiation: action.negotiation || null,
            providerCounterDate: new Date(),
          },
        });
      } else {
        // Para cláusulas personalizadas, actualizar el registro existente
        return prisma.quoteResponseClause.update({
          where: { id: clauseId },
          data: {
            providerCounterAction: action.action,
            providerCounterNegotiation: action.negotiation || null,
            providerCounterDate: new Date(),
          },
        });
      }
    });

    await Promise.all(updates);

    // Verificar si todas las cláusulas están aceptadas por ambas partes
    const allClauseResponses = await prisma.quoteResponseClause.findMany({
      where: { quoteResponseId: id },
    });

    // Verificar si todas las cláusulas con acción del cliente están aceptadas
    const allAccepted = allClauseResponses
      .filter(cr => cr.clientAction) // Solo las que el cliente ha revisado
      .every(cr => 
        (cr.clientAction === 'ACCEPT') || 
        (cr.clientAction === 'NEGOTIATE' && cr.providerCounterAction === 'ACCEPT')
      );

    const allReviewed = allClauseResponses.every(cr => cr.clientAction !== null);

    // Actualizar el registro de revisión con el estado actualizado
    await prisma.quoteResponseReview.upsert({
      where: { quoteResponseId: id },
      create: {
        quoteResponseId: id,
        isReviewed: true,
        allClausesReviewed: allReviewed,
        allClausesAccepted: allAccepted,
        firstReviewedAt: new Date(),
        lastReviewedAt: new Date(),
      },
      update: {
        allClausesReviewed: allReviewed,
        allClausesAccepted: allAccepted,
        lastReviewedAt: new Date(),
      },
    });

    // Si todas están aceptadas, actualizar el estado de la respuesta
    if (allAccepted && allClauseResponses.some(cr => cr.clientAction)) {
      await prisma.quoteResponse.update({
        where: { id },
        data: {
          status: 'ALL_CLAUSES_ACCEPTED',
        },
      });
    }

    // Notificar al cliente
    const hasCounterNegotiations = Object.values(providerActions).some(
      (action: any) => action.action === 'NEGOTIATE'
    );
    
    if (hasCounterNegotiations) {
      await prisma.notification.create({
        data: {
          userId: quoteResponse.quoteRequest.clientId,
          type: 'QUOTE_RESPONSE_UPDATED',
          title: 'Proveedor ha respondido',
          message: `${quoteResponse.provider?.companyName || 'El proveedor'} ha respondido a tus negociaciones`,
          quoteResponseId: id,
        },
      });
    } else if (allAccepted) {
      // Notificar que todas las cláusulas están aceptadas
      await prisma.notification.create({
        data: {
          userId: quoteResponse.quoteRequest.clientId,
          type: 'QUOTE_RESPONSE_UPDATED',
          title: 'Todas las cláusulas aceptadas',
          message: `${quoteResponse.provider?.companyName || 'El proveedor'} ha aceptado todas las cláusulas`,
          quoteResponseId: id,
        },
      });
    }

    return NextResponse.json({ 
      success: true,
      message: 'Respuesta guardada exitosamente',
      allClausesAccepted: allAccepted,
    });
  } catch (error) {
    console.error('Error al guardar contra-respuesta del proveedor:', error);
    return NextResponse.json(
      { error: 'Error al guardar contra-respuesta del proveedor' },
      { status: 500 }
    );
  }
}
