
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || !session.user) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { id } = params;
    const { clauseActions } = await request.json();

    // Obtener la respuesta de cotización
    const quoteResponse = await prisma.quoteResponse.findUnique({
      where: { id },
      include: {
        quoteRequest: true,
        clauseResponses: true,
      },
    });

    if (!quoteResponse) {
      return NextResponse.json({ error: 'Oferta no encontrada' }, { status: 404 });
    }

    // Verificar que el usuario sea el cliente
    if (quoteResponse.quoteRequest.clientId !== session.user.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 403 });
    }

    // Actualizar o crear registros para cada cláusula con la acción del cliente
    const updates = Object.entries(clauseActions).map(async ([clauseId, action]: [string, any]) => {
      // Verificar si es una cláusula estándar (IDs generados: energy-price-, power-price-, etc.)
      const isStandardClause = clauseId.startsWith('energy-price-') || 
                               clauseId.startsWith('power-price-') || 
                               clauseId.startsWith('term-months-') ||
                               clauseId.startsWith('payment-terms-') ||
                               clauseId.startsWith('guarantees-') ||
                               clauseId.startsWith('energy-source-') ||
                               clauseId.startsWith('delivery-node-');

      if (isStandardClause) {
        // Para cláusulas estándar, usar upsert con el ID como clave única
        return prisma.quoteResponseClause.upsert({
          where: { 
            id: clauseId,
          },
          create: {
            id: clauseId,
            quoteResponseId: id,
            clauseId: clauseId, // Usar el mismo ID como clauseId para cláusulas estándar
            action: 'NEGOTIATE', // Las cláusulas estándar siempre son negociación inicial
            negotiation: null,
            clientAction: action.action,
            clientNegotiation: action.negotiation || null,
            clientActionDate: new Date(),
          },
          update: {
            clientAction: action.action,
            clientNegotiation: action.negotiation || null,
            clientActionDate: new Date(),
          },
        });
      } else {
        // Para cláusulas personalizadas, actualizar el registro existente
        return prisma.quoteResponseClause.update({
          where: { id: clauseId },
          data: {
            clientAction: action.action,
            clientNegotiation: action.negotiation || null,
            clientActionDate: new Date(),
          },
        });
      }
    });

    await Promise.all(updates);

    // Verificar si todas las cláusulas fueron revisadas y aceptadas
    const allClauses = await prisma.quoteResponseClause.findMany({
      where: { quoteResponseId: id },
    });

    const allReviewed = allClauses.every((c: any) => c.clientAction !== null);
    
    // Una cláusula está aceptada si:
    // 1. El cliente la aceptó directamente (clientAction === 'ACCEPT')
    // 2. El cliente negoció y el proveedor aceptó (clientAction === 'NEGOTIATE' && providerCounterAction === 'ACCEPT')
    const allAccepted = allClauses.every((c: any) => 
      c.clientAction === 'ACCEPT' || 
      (c.clientAction === 'NEGOTIATE' && c.providerCounterAction === 'ACCEPT')
    );

    // Crear o actualizar el registro de revisión
    await prisma.quoteResponseReview.upsert({
      where: { quoteResponseId: id },
      create: {
        quoteResponseId: id,
        isReviewed: true,
        allClausesReviewed: allReviewed,
        allClausesAccepted: allAccepted,
        firstReviewedAt: new Date(),
        lastReviewedAt: new Date(),
      },
      update: {
        allClausesReviewed: allReviewed,
        allClausesAccepted: allAccepted,
        lastReviewedAt: new Date(),
      },
    });

    // Si hay negociaciones, notificar al proveedor
    const hasNegotiations = Object.values(clauseActions).some((action: any) => action.action === 'NEGOTIATE');
    if (hasNegotiations) {
      await prisma.notification.create({
        data: {
          userId: quoteResponse.providerId,
          type: 'QUOTE_RESPONSE_UPDATED',
          title: 'Cliente solicita negociación',
          message: `El cliente ha revisado tu oferta y solicita negociar algunas cláusulas`,
          quoteResponseId: id,
        },
      });
    }

    return NextResponse.json({ 
      success: true,
      allClausesReviewed: allReviewed,
      allClausesAccepted: allAccepted,
    });
  } catch (error) {
    console.error('Error al guardar revisión del cliente:', error);
    return NextResponse.json(
      { error: 'Error al guardar revisión del cliente' },
      { status: 500 }
    );
  }
}
