
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;

    // Buscar si existe un ClientOffer asociado con este QuoteResponse
    const clientOffer = await prisma.clientOffer.findFirst({
      where: {
        offerId: id
      },
      select: {
        id: true
      }
    });

    if (!clientOffer) {
      return NextResponse.json(
        { clientOfferId: null },
        { status: 200 }
      );
    }

    return NextResponse.json({
      clientOfferId: clientOffer.id
    });

  } catch (error) {
    console.error('Error fetching client offer:', error);
    return NextResponse.json(
      { error: 'Error al buscar la solicitud del cliente' },
      { status: 500 }
    );
  }
}
