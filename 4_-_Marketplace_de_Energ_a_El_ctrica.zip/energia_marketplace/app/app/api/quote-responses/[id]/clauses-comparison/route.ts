
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || !session.user) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { id } = params;

    // Obtener la respuesta de cotización con todas las relaciones necesarias
    const quoteResponse = await prisma.quoteResponse.findUnique({
      where: { id },
      include: {
        quoteRequest: {
          include: {
            clauses: true,
          },
        },
        clauseResponses: true,
        review: true,
      },
    });

    if (!quoteResponse) {
      return NextResponse.json({ error: 'Oferta no encontrada' }, { status: 404 });
    }

    // Verificar que el usuario sea el cliente o el proveedor
    const isClient = quoteResponse.quoteRequest.clientId === session.user.id;
    const isProvider = quoteResponse.providerId === session.user.id;
    
    if (!isClient && !isProvider) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 403 });
    }

    // Crear cláusulas estándar para comparación
    const standardClauses = [];

    // 1. Precio de Energía
    if (quoteResponse.energyPricePerMWh !== null && quoteResponse.energyPricePerMWh !== undefined) {
      const clauseId = `energy-price-${quoteResponse.id}`;
      const providerResponse = quoteResponse.clauseResponses.find(
        (cr: any) => cr.id === clauseId
      );
      
      standardClauses.push({
        id: clauseId,
        originalClause: {
          id: clauseId,
          clauseName: 'Precio de Energía',
          clauseDescription: 'A definir según ofertas recibidas',
          isRequired: true,
        },
        providerAction: 'NEGOTIATE',
        providerNegotiation: `$${quoteResponse.energyPricePerMWh.toFixed(2)}/MWh`,
        clientAction: providerResponse?.clientAction || null,
        clientNegotiation: providerResponse?.clientNegotiation || null,
        clientActionDate: providerResponse?.clientActionDate || null,
        providerCounterAction: providerResponse?.providerCounterAction || null,
        providerCounterNegotiation: providerResponse?.providerCounterNegotiation || null,
        providerCounterDate: providerResponse?.providerCounterDate || null,
      });
    }

    // 2. Precio de Potencia
    if (quoteResponse.powerPricePerKW !== null && quoteResponse.powerPricePerKW !== undefined) {
      const clauseId = `power-price-${quoteResponse.id}`;
      const providerResponse = quoteResponse.clauseResponses.find(
        (cr: any) => cr.id === clauseId
      );
      
      standardClauses.push({
        id: clauseId,
        originalClause: {
          id: clauseId,
          clauseName: 'Precio de Potencia',
          clauseDescription: 'A definir según ofertas recibidas',
          isRequired: true,
        },
        providerAction: 'NEGOTIATE',
        providerNegotiation: `$${quoteResponse.powerPricePerKW.toFixed(2)}/kW-mes`,
        clientAction: providerResponse?.clientAction || null,
        clientNegotiation: providerResponse?.clientNegotiation || null,
        clientActionDate: providerResponse?.clientActionDate || null,
        providerCounterAction: providerResponse?.providerCounterAction || null,
        providerCounterNegotiation: providerResponse?.providerCounterNegotiation || null,
        providerCounterDate: providerResponse?.providerCounterDate || null,
      });
    }

    // 3. Plazo del contrato
    if (quoteResponse.quoteRequest.termMonths) {
      const clauseId = `term-months-${quoteResponse.id}`;
      const providerResponse = quoteResponse.clauseResponses.find(
        (cr: any) => cr.id === clauseId
      );
      
      standardClauses.push({
        id: clauseId,
        originalClause: {
          id: clauseId,
          clauseName: 'Plazo del Contrato',
          clauseDescription: `${quoteResponse.quoteRequest.termMonths} meses`,
          isRequired: true,
        },
        providerAction: 'ACCEPT',
        providerNegotiation: null,
        clientAction: providerResponse?.clientAction || null,
        clientNegotiation: providerResponse?.clientNegotiation || null,
        clientActionDate: providerResponse?.clientActionDate || null,
        providerCounterAction: providerResponse?.providerCounterAction || null,
        providerCounterNegotiation: providerResponse?.providerCounterNegotiation || null,
        providerCounterDate: providerResponse?.providerCounterDate || null,
      });
    }

    // 4. Condiciones de Pago
    if (quoteResponse.quoteRequest.paymentTerms || quoteResponse.paymentTerms) {
      const clauseId = `payment-terms-${quoteResponse.id}`;
      const providerResponse = quoteResponse.clauseResponses.find(
        (cr: any) => cr.id === clauseId
      );
      
      const clientRequest = quoteResponse.quoteRequest.paymentTerms || 'No especificado';
      const providerOffer = quoteResponse.paymentTerms || 'No especificado';
      const matches = clientRequest === providerOffer;
      
      standardClauses.push({
        id: clauseId,
        originalClause: {
          id: clauseId,
          clauseName: 'Condiciones de Pago',
          clauseDescription: clientRequest,
          isRequired: false,
        },
        providerAction: matches ? 'ACCEPT' : 'NEGOTIATE',
        providerNegotiation: matches ? null : providerOffer,
        clientAction: providerResponse?.clientAction || null,
        clientNegotiation: providerResponse?.clientNegotiation || null,
        clientActionDate: providerResponse?.clientActionDate || null,
        providerCounterAction: providerResponse?.providerCounterAction || null,
        providerCounterNegotiation: providerResponse?.providerCounterNegotiation || null,
        providerCounterDate: providerResponse?.providerCounterDate || null,
      });
    }

    // 5. Garantías
    if (quoteResponse.quoteRequest.guaranteesOffered || quoteResponse.guaranteesRequired) {
      const clauseId = `guarantees-${quoteResponse.id}`;
      const providerResponse = quoteResponse.clauseResponses.find(
        (cr: any) => cr.id === clauseId
      );
      
      const clientOffer = quoteResponse.quoteRequest.guaranteesOffered || 'No especificadas';
      const providerRequirement = quoteResponse.guaranteesRequired || 'No especificadas';
      const matches = clientOffer === providerRequirement;
      
      standardClauses.push({
        id: clauseId,
        originalClause: {
          id: clauseId,
          clauseName: 'Garantías',
          clauseDescription: `Cliente ofrece: ${clientOffer}`,
          isRequired: false,
        },
        providerAction: matches ? 'ACCEPT' : 'NEGOTIATE',
        providerNegotiation: matches ? null : `Proveedor requiere: ${providerRequirement}`,
        clientAction: providerResponse?.clientAction || null,
        clientNegotiation: providerResponse?.clientNegotiation || null,
        clientActionDate: providerResponse?.clientActionDate || null,
        providerCounterAction: providerResponse?.providerCounterAction || null,
        providerCounterNegotiation: providerResponse?.providerCounterNegotiation || null,
        providerCounterDate: providerResponse?.providerCounterDate || null,
      });
    }

    // 6. Fuente de Generación
    if (quoteResponse.quoteRequest.preferredEnergySource || quoteResponse.generationSource) {
      const clauseId = `energy-source-${quoteResponse.id}`;
      const providerResponse = quoteResponse.clauseResponses.find(
        (cr: any) => cr.id === clauseId
      );
      
      const clientPreference = quoteResponse.quoteRequest.preferredEnergySource || 'Sin preferencia';
      const providerOffer = quoteResponse.generationSource || 'No especificada';
      const matches = clientPreference === providerOffer || clientPreference === 'Sin preferencia';
      
      standardClauses.push({
        id: clauseId,
        originalClause: {
          id: clauseId,
          clauseName: 'Fuente de Generación',
          clauseDescription: clientPreference,
          isRequired: false,
        },
        providerAction: matches ? 'ACCEPT' : 'NEGOTIATE',
        providerNegotiation: matches ? null : providerOffer,
        clientAction: providerResponse?.clientAction || null,
        clientNegotiation: providerResponse?.clientNegotiation || null,
        clientActionDate: providerResponse?.clientActionDate || null,
        providerCounterAction: providerResponse?.providerCounterAction || null,
        providerCounterNegotiation: providerResponse?.providerCounterNegotiation || null,
        providerCounterDate: providerResponse?.providerCounterDate || null,
      });
    }

    // 7. Nodo de Entrega
    if (quoteResponse.quoteRequest.deliveryNode || quoteResponse.deliveryNode) {
      const clauseId = `delivery-node-${quoteResponse.id}`;
      const providerResponse = quoteResponse.clauseResponses.find(
        (cr: any) => cr.id === clauseId
      );
      
      const clientPreference = quoteResponse.quoteRequest.deliveryNode || 'No especificado';
      const providerOffer = quoteResponse.deliveryNode || 'No especificado';
      const matches = clientPreference === providerOffer;
      
      standardClauses.push({
        id: clauseId,
        originalClause: {
          id: clauseId,
          clauseName: 'Nodo de Entrega',
          clauseDescription: clientPreference,
          isRequired: false,
        },
        providerAction: matches ? 'ACCEPT' : 'NEGOTIATE',
        providerNegotiation: matches ? null : providerOffer,
        clientAction: providerResponse?.clientAction || null,
        clientNegotiation: providerResponse?.clientNegotiation || null,
        clientActionDate: providerResponse?.clientActionDate || null,
        providerCounterAction: providerResponse?.providerCounterAction || null,
        providerCounterNegotiation: providerResponse?.providerCounterNegotiation || null,
        providerCounterDate: providerResponse?.providerCounterDate || null,
      });
    }

    // Combinar las cláusulas estándar con las cláusulas personalizadas
    const customClauses = quoteResponse.quoteRequest.clauses.map((originalClause: any) => {
      const providerResponse = quoteResponse.clauseResponses.find(
        (cr: any) => cr.clauseId === originalClause.id
      );

      return {
        id: providerResponse?.id || originalClause.id,
        originalClause: {
          id: originalClause.id,
          clauseName: originalClause.clauseName,
          clauseDescription: originalClause.clauseDescription,
          isRequired: originalClause.isRequired,
        },
        providerAction: providerResponse?.action || 'ACCEPT',
        providerNegotiation: providerResponse?.negotiation,
        clientAction: providerResponse?.clientAction,
        clientNegotiation: providerResponse?.clientNegotiation,
        clientActionDate: providerResponse?.clientActionDate,
        providerCounterAction: providerResponse?.providerCounterAction,
        providerCounterNegotiation: providerResponse?.providerCounterNegotiation,
        providerCounterDate: providerResponse?.providerCounterDate,
      };
    });

    const clausesComparison = [...standardClauses, ...customClauses];

    return NextResponse.json({
      clauses: clausesComparison,
      review: quoteResponse.review,
    });
  } catch (error) {
    console.error('Error al obtener comparación de cláusulas:', error);
    return NextResponse.json(
      { error: 'Error al obtener comparación de cláusulas' },
      { status: 500 }
    );
  }
}
