
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

// GET - Obtener contratos de cotizaciones del usuario
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });
    }

    // Obtener contratos según el tipo de usuario
    const where = user.userType === 'PROVIDER'
      ? { providerId: user.id }
      : { clientId: user.id };

    const contracts = await prisma.quoteContract.findMany({
      where,
      include: {
        client: {
          select: {
            id: true,
            name: true,
            email: true,
            companyName: true,
          },
        },
        provider: {
          select: {
            id: true,
            name: true,
            email: true,
            companyName: true,
          },
        },
        quoteRequest: {
          select: {
            id: true,
            title: true,
            description: true,
            termMonths: true,
          },
        },
        quoteResponse: {
          select: {
            id: true,
            energyPricePerMWh: true,
            powerPricePerKW: true,
            totalEstimated: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    return NextResponse.json({ contracts });
  } catch (error) {
    console.error('Error al obtener contratos de cotizaciones:', error);
    return NextResponse.json(
      { error: 'Error al obtener contratos' },
      { status: 500 }
    );
  }
}
