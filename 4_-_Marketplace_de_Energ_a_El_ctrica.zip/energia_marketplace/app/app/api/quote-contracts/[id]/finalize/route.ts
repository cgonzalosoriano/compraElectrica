
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const contractId = params.id;

    // Buscar el usuario actual
    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email }
    });

    if (!currentUser) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });
    }

    // Buscar el QuoteContract
    const quoteContract = await prisma.quoteContract.findFirst({
      where: {
        id: contractId,
        OR: [
          { clientId: currentUser.id },
          { providerId: currentUser.id }
        ]
      }
    });

    if (!quoteContract) {
      return NextResponse.json({ error: 'Contrato no encontrado' }, { status: 404 });
    }

    // Verificar que ambas partes hayan firmado
    if (!quoteContract.clientSignedDocumentPath || !quoteContract.providerSignedDocumentPath) {
      return NextResponse.json({ 
        error: 'Ambas partes deben firmar antes de finalizar el contrato' 
      }, { status: 400 });
    }

    // Finalizar el contrato
    await prisma.quoteContract.update({
      where: { id: contractId },
      data: { 
        status: 'COMPLETED',
        signedAt: new Date()
      }
    });

    return NextResponse.json({ 
      message: 'Contrato finalizado exitosamente',
      status: 'COMPLETED'
    });

  } catch (error) {
    console.error('Error al finalizar contrato:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
