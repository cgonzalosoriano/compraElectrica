
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

// GET - Obtener contrato específico
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });
    }

    const contract = await prisma.quoteContract.findUnique({
      where: { id: params.id },
      include: {
        client: true,
        provider: true,
        quoteRequest: {
          include: {
            periods: true,
            clauses: true,
          },
        },
        quoteResponse: {
          include: {
            periods: true,
            clauseResponses: true,
          },
        },
        negotiations: {
          include: {
            proposer: {
              select: {
                id: true,
                name: true,
                email: true,
                companyName: true,
              },
            },
            recipient: {
              select: {
                id: true,
                name: true,
                email: true,
                companyName: true,
              },
            },
          },
          orderBy: {
            createdAt: 'desc',
          },
        },
      },
    });

    if (!contract) {
      return NextResponse.json({ error: 'Contrato no encontrado' }, { status: 404 });
    }

    // Verificar que el usuario sea parte del contrato
    if (contract.clientId !== user.id && contract.providerId !== user.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 403 });
    }

    return NextResponse.json({ contract });
  } catch (error) {
    console.error('Error al obtener contrato:', error);
    return NextResponse.json(
      { error: 'Error al obtener contrato' },
      { status: 500 }
    );
  }
}
