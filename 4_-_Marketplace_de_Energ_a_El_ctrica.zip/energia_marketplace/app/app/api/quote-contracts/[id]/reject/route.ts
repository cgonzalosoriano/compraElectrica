
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

// POST - Rechazar contrato de cotización
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });
    }

    const { reason } = await request.json();

    const contract = await prisma.quoteContract.findUnique({
      where: { id: params.id },
      include: {
        client: true,
        provider: true,
      },
    });

    if (!contract) {
      return NextResponse.json({ error: 'Contrato no encontrado' }, { status: 404 });
    }

    // Verificar que el usuario sea parte del contrato
    if (contract.clientId !== user.id && contract.providerId !== user.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 403 });
    }

    // Actualizar estado del contrato
    const updatedContract = await prisma.quoteContract.update({
      where: { id: params.id },
      data: {
        status: 'CANCELLED',
      },
    });

    // Actualizar estado de la respuesta de cotización
    await prisma.quoteResponse.update({
      where: { id: contract.quoteResponseId },
      data: {
        status: 'REJECTED',
      },
    });

    // Notificar a la otra parte
    const isClient = contract.clientId === user.id;
    const recipientId = isClient ? contract.providerId : contract.clientId;
    
    await prisma.notification.create({
      data: {
        userId: recipientId,
        type: 'CONTRACT_UPDATE',
        title: 'Contrato rechazado',
        message: `${isClient ? 'El cliente' : 'El proveedor'} ha rechazado el contrato. Motivo: ${reason || 'Sin especificar'}`,
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Contrato rechazado exitosamente',
      contract: updatedContract,
    });
  } catch (error) {
    console.error('Error al rechazar contrato:', error);
    return NextResponse.json(
      { error: 'Error al rechazar contrato' },
      { status: 500 }
    );
  }
}
