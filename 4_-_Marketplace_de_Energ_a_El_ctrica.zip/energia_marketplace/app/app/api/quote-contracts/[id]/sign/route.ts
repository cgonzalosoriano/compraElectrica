
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

// POST - Firmar contrato de cotización
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });
    }

    const { signedDocumentPath } = await request.json();

    if (!signedDocumentPath) {
      return NextResponse.json(
        { error: 'Ruta del documento firmado requerida' },
        { status: 400 }
      );
    }

    const contract = await prisma.quoteContract.findUnique({
      where: { id: params.id },
      include: {
        client: true,
        provider: true,
      },
    });

    if (!contract) {
      return NextResponse.json({ error: 'Contrato no encontrado' }, { status: 404 });
    }

    // Verificar que el usuario sea parte del contrato
    if (contract.clientId !== user.id && contract.providerId !== user.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 403 });
    }

    // Determinar si es el cliente o el proveedor quien firma
    const isClient = contract.clientId === user.id;

    // Actualizar la firma correspondiente
    if (isClient) {
      await prisma.quoteContract.update({
        where: { id: params.id },
        data: {
          clientSignedDocumentPath: signedDocumentPath,
          clientSignedAt: new Date()
        }
      });
    } else {
      await prisma.quoteContract.update({
        where: { id: params.id },
        data: {
          providerSignedDocumentPath: signedDocumentPath,
          providerSignedAt: new Date()
        }
      });
    }

    // Verificar si ambas partes han firmado
    const updatedContract = await prisma.quoteContract.findUnique({
      where: { id: params.id }
    });

    const bothPartiesSigned = updatedContract?.clientSignedDocumentPath && 
                              updatedContract?.providerSignedDocumentPath;

    if (bothPartiesSigned) {
      // Actualizar el estado a COMPLETED
      await prisma.quoteContract.update({
        where: { id: params.id },
        data: { 
          status: 'COMPLETED',
          signedAt: new Date()
        }
      });

      return NextResponse.json({
        message: '¡Contrato firmado por ambas partes! El contrato está ahora completado.',
        bothPartiesSigned: true
      });
    } else {
      return NextResponse.json({
        message: 'Tu firma ha sido registrada. Esperando la firma de la otra parte.',
        bothPartiesSigned: false
      });
    }

  } catch (error) {
    console.error('Error al firmar contrato:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
