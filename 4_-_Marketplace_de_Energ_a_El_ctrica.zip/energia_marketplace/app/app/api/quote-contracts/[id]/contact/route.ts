
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

// POST - Contactar sobre el contrato
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });
    }

    const { message: messageContent } = await request.json();

    if (!messageContent) {
      return NextResponse.json(
        { error: 'Mensaje requerido' },
        { status: 400 }
      );
    }

    const contract = await prisma.quoteContract.findUnique({
      where: { id: params.id },
      include: {
        client: true,
        provider: true,
      },
    });

    if (!contract) {
      return NextResponse.json({ error: 'Contrato no encontrado' }, { status: 404 });
    }

    // Verificar que el usuario sea parte del contrato
    if (contract.clientId !== user.id && contract.providerId !== user.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 403 });
    }

    // Determinar el destinatario
    const isClient = contract.clientId === user.id;
    const recipientId = isClient ? contract.providerId : contract.clientId;

    // Crear mensaje
    await prisma.message.create({
      data: {
        senderId: user.id,
        recipientId,
        content: messageContent,
        subject: `Mensaje sobre contrato de cotización #${contract.id.substring(0, 8)}`,
        messageType: 'NEGOTIATION',
      },
    });

    // Crear notificación
    await prisma.notification.create({
      data: {
        userId: recipientId,
        type: 'CONTRACT_UPDATE',
        title: 'Nuevo mensaje sobre contrato',
        message: `Has recibido un mensaje sobre el contrato de cotización`,
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Mensaje enviado exitosamente',
    });
  } catch (error) {
    console.error('Error al enviar mensaje:', error);
    return NextResponse.json(
      { error: 'Error al enviar mensaje' },
      { status: 500 }
    );
  }
}
