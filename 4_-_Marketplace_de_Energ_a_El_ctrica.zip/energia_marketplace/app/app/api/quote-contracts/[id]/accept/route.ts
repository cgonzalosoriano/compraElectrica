
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const contractId = params.id;

    // Buscar el usuario actual
    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email }
    });

    if (!currentUser) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });
    }

    // Buscar el QuoteContract
    const quoteContract = await prisma.quoteContract.findFirst({
      where: {
        id: contractId,
        OR: [
          { clientId: currentUser.id },
          { providerId: currentUser.id }
        ]
      },
      include: {
        client: true,
        provider: true,
        quoteResponse: true
      }
    });

    if (!quoteContract) {
      return NextResponse.json({ error: 'Contrato no encontrado' }, { status: 404 });
    }

    // Actualizar estado a PENDING_SIGNATURE
    await prisma.quoteContract.update({
      where: { id: contractId },
      data: { status: 'PENDING_SIGNATURE' }
    });

    return NextResponse.json({ 
      message: 'Contrato aceptado exitosamente',
      status: 'PENDING_SIGNATURE'
    });

  } catch (error) {
    console.error('Error al aceptar contrato:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
