
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

// POST - Generar PDF del contrato de cotización
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });
    }

    const contract = await prisma.quoteContract.findUnique({
      where: { id: params.id },
      include: {
        client: true,
        provider: true,
        quoteRequest: {
          include: {
            periods: true,
            clauses: true,
          },
        },
        quoteResponse: {
          include: {
            periods: true,
            clauseResponses: true,
          },
        },
      },
    });

    if (!contract) {
      return NextResponse.json({ error: 'Contrato no encontrado' }, { status: 404 });
    }

    // Verificar que el usuario sea parte del contrato
    if (contract.clientId !== user.id && contract.providerId !== user.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 403 });
    }

    // Generar PDF (implementación simplificada - en producción usar una librería de PDF)
    const pdfContent = {
      contractId: contract.id,
      date: new Date().toLocaleDateString('es-AR'),
      provider: {
        name: contract.provider.companyName || contract.provider.name,
        email: contract.provider.email,
        cuit: contract.provider.cuit,
      },
      client: {
        name: contract.client.companyName || contract.client.name,
        email: contract.client.email,
        cuit: contract.client.cuit,
      },
      terms: contract.terms,
      quoteRequest: contract.quoteRequest,
      quoteResponse: contract.quoteResponse,
      status: contract.status,
    };

    // TODO: Implementar generación real de PDF usando una librería como pdf-lib o pdfkit
    // Por ahora, retornamos el contenido en formato JSON
    
    return NextResponse.json({
      success: true,
      message: 'PDF generado exitosamente',
      pdfContent,
      downloadUrl: `/api/quote-contracts/${params.id}/download`, // URL de descarga
    });
  } catch (error) {
    console.error('Error al generar PDF del contrato:', error);
    return NextResponse.json(
      { error: 'Error al generar PDF' },
      { status: 500 }
    );
  }
}
