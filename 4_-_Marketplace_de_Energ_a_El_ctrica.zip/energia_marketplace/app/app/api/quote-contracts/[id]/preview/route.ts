
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const contractId = params.id;

    // Buscar el usuario actual
    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email }
    });

    if (!currentUser) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });
    }

    // Buscar en QuoteContract
    const quoteContract = await prisma.quoteContract.findFirst({
      where: {
        id: contractId,
        OR: [
          { clientId: currentUser.id },
          { providerId: currentUser.id }
        ]
      },
      include: {
        client: true,
        provider: true,
        quoteRequest: {
          include: {
            periods: true
          }
        },
        quoteResponse: {
          include: {
            periods: true
          }
        }
      }
    });

    if (!quoteContract) {
      return NextResponse.json({ error: 'Contrato no encontrado' }, { status: 404 });
    }

    // Información sobre las firmas
    const clientSigned = !!quoteContract.clientSignedDocumentPath;
    const providerSigned = !!quoteContract.providerSignedDocumentPath;
    const isCurrentUserClient = quoteContract.clientId === currentUser.id;
    const isCurrentUserProvider = quoteContract.providerId === currentUser.id;
    
    // Determinar qué documentos están disponibles para descargar
    const canDownloadClientSignedDoc = clientSigned && isCurrentUserProvider;
    const canDownloadProviderSignedDoc = providerSigned && isCurrentUserClient;

    // Extraer datos de precios y términos
    const energyPrice = quoteContract.quoteResponse?.energyPricePerMWh || 0;
    const powerPrice = quoteContract.quoteResponse?.powerPricePerKW || 0;
    const term = quoteContract.quoteRequest?.termMonths || 0;
    
    // Calcular volumen total
    const totalEnergyMWh = quoteContract.quoteRequest?.periods.reduce(
      (sum: number, period: { energyMWh: number | null }) => sum + (period.energyMWh || 0), 
      0
    ) || 0;

    // Retornar datos del QuoteContract
    return NextResponse.json({
      type: 'quote_contract',
      id: quoteContract.id,
      clientName: quoteContract.client.companyName || quoteContract.client.name || 'N/A',
      providerName: quoteContract.provider.companyName || quoteContract.provider.name || 'N/A',
      date: new Date().toLocaleDateString('es-AR', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      }),
      energyPrice,
      powerPrice,
      term,
      volume: totalEnergyMWh,
      status: quoteContract.status,
      terms: quoteContract.terms || 'Términos y condiciones según solicitud de cotización',
      startDate: quoteContract.quoteRequest?.startDate?.toLocaleDateString('es-AR') || 'A convenir',
      endDate: 'A convenir según términos del contrato',
      // Información de firmas
      signatures: {
        clientSigned,
        providerSigned,
        clientSignedAt: quoteContract.clientSignedAt?.toLocaleDateString('es-AR'),
        providerSignedAt: quoteContract.providerSignedAt?.toLocaleDateString('es-AR'),
        isCurrentUserClient,
        isCurrentUserProvider,
        canDownloadClientSignedDoc,
        canDownloadProviderSignedDoc,
        bothPartiesSigned: clientSigned && providerSigned
      }
    });

  } catch (error) {
    console.error('Error al obtener datos del contrato:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
