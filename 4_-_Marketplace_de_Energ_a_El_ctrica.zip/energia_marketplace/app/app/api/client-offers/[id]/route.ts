

import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { PrismaClient } from "@prisma/client"

export const dynamic = "force-dynamic"

const prisma = new PrismaClient()

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || session.user.userType !== 'PROVIDER') {
      return NextResponse.json(
        { error: "No autorizado" },
        { status: 401 }
      )
    }

    const body = await request.json()
    const { status, message } = body

    if (!['ACCEPTED', 'REJECTED'].includes(status)) {
      return NextResponse.json(
        { error: "Estado inválido" },
        { status: 400 }
      )
    }

    // Verificar que la solicitud existe y pertenece a una oferta del proveedor
    const clientOffer = await prisma.clientOffer.findUnique({
      where: { id: params.id },
      include: {
        offer: {
          include: {
            provider: true
          }
        },
        client: true
      }
    })

    if (!clientOffer) {
      return NextResponse.json(
        { error: "Solicitud no encontrada" },
        { status: 404 }
      )
    }

    if (!clientOffer.offer) {
      return NextResponse.json(
        { error: "La oferta original fue eliminada, pero esta solicitud puede continuar su proceso de negociación" },
        { status: 400 }
      )
    }

    if (clientOffer.offer.providerId !== session.user.id) {
      return NextResponse.json(
        { error: "No autorizado para modificar esta solicitud" },
        { status: 403 }
      )
    }

    // Actualizar el estado de la solicitud
    const updatedClientOffer = await prisma.clientOffer.update({
      where: { id: params.id },
      data: {
        status
      },
      include: {
        offer: {
          include: {
            provider: true
          }
        },
        client: true
      }
    })

    // Si se acepta, podemos crear una transacción pendiente
    if (status === 'ACCEPTED' && clientOffer.requestedVolume && clientOffer.offer) {
      const totalAmount = clientOffer.requestedVolume * clientOffer.offer.energyPrice;
      const commissionAmount = totalAmount * 0.02; // 2% de comisión

      await prisma.transaction.create({
        data: {
          clientOfferId: clientOffer.id,
          offerId: clientOffer.offerId,
          clientId: clientOffer.clientId,
          providerId: clientOffer.offer.providerId,
          agreedEnergyPrice: clientOffer.offer.energyPrice,
          agreedPowerPrice: clientOffer.offer.powerPrice,
          agreedVolume: clientOffer.requestedVolume,
          totalAmount: totalAmount,
          commissionAmount: commissionAmount,
          status: 'NEGOTIATING' // Usar un estado válido del enum
        }
      })
    }

    // Enviar mensaje de respuesta si se proporcionó
    if (message && message.trim()) {
      await prisma.message.create({
        data: {
          senderId: session.user.id,
          recipientId: clientOffer.clientId,
          clientOfferId: clientOffer.id,
          subject: `Respuesta a solicitud: ${clientOffer.offer?.generationSource || 'Oferta eliminada'}`,
          content: message.trim(),
          messageType: 'NEGOTIATION'
        }
      })
    }

    return NextResponse.json({
      clientOffer: updatedClientOffer,
      message: `Solicitud ${status === 'ACCEPTED' ? 'aceptada' : 'rechazada'} exitosamente`
    })

  } catch (error) {
    console.error("Error al actualizar solicitud:", error)
    return NextResponse.json(
      { error: "Error interno del servidor" },
      { status: 500 }
    )
  }
}
