
import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { PrismaClient } from "@prisma/client"

export const dynamic = "force-dynamic"

const prisma = new PrismaClient()

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || session.user.userType !== 'CLIENT') {
      return NextResponse.json(
        { error: "No autorizado" },
        { status: 401 }
      )
    }

    const body = await request.json()
    const {
      offerId,
      userNumber,
      distributorName,
      region,
      address,
      tariffType,
      requestedVolume,
      message
    } = body

    // Verificar que la oferta existe y está activa
    const offer = await prisma.offer.findUnique({
      where: { id: offerId },
      include: { provider: true }
    })

    if (!offer || offer.status !== 'ACTIVE') {
      return NextResponse.json(
        { error: "Oferta no disponible" },
        { status: 400 }
      )
    }

    // Verificar que no haya solicitud duplicada
    const existingClientOffer = await prisma.clientOffer.findFirst({
      where: {
        offerId,
        clientId: session.user.id
      }
    })

    if (existingClientOffer) {
      return NextResponse.json(
        { error: "Ya has solicitado esta oferta" },
        { status: 400 }
      )
    }

    // Crear la solicitud de cliente
    const clientOffer = await prisma.clientOffer.create({
      data: {
        offerId,
        clientId: session.user.id,
        userNumber,
        distributorName,
        region,
        address,
        tariffType,
        requestedVolume: parseFloat(requestedVolume),
        status: 'PENDING'
      },
      include: {
        offer: {
          include: {
            provider: true
          }
        },
        client: true
      }
    })

    // Si hay mensaje, crear mensaje inicial
    if (message && message.trim()) {
      await prisma.message.create({
        data: {
          senderId: session.user.id,
          recipientId: offer.providerId,
          clientOfferId: clientOffer.id,
          subject: `Nueva solicitud para: ${offer.generationSource}`,
          content: message.trim(),
          messageType: 'NEGOTIATION'
        }
      })
    }

    return NextResponse.json(
      { 
        clientOffer,
        message: "Solicitud enviada exitosamente"
      },
      { status: 201 }
    )
  } catch (error) {
    console.error("Error al crear solicitud:", error)
    return NextResponse.json(
      { error: "Error interno del servidor" },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session) {
      return NextResponse.json(
        { error: "No autorizado" },
        { status: 401 }
      )
    }

    const clientOffers = await prisma.clientOffer.findMany({
      where: { clientId: session.user.id },
      include: {
        offer: {
          include: {
            provider: true
          }
        },
        transaction: true
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ clientOffers })
  } catch (error) {
    console.error("Error al obtener solicitudes:", error)
    return NextResponse.json(
      { error: "Error interno del servidor" },
      { status: 500 }
    )
  }
}
