
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function GET(
  request: NextRequest,
  { params }: { params: { clientOfferId: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const { clientOfferId } = params

    // Verificar que el usuario tenga acceso a esta oferta
    const clientOffer = await prisma.clientOffer.findUnique({
      where: { id: clientOfferId },
      include: { 
        client: true,
        offer: {
          include: {
            provider: true
          }
        }
      }
    })

    if (!clientOffer) {
      return NextResponse.json({ error: 'Oferta no encontrada' }, { status: 404 })
    }

    if (!clientOffer.offer) {
      return NextResponse.json({ 
        error: 'No se puede acceder a negociaciones: la oferta original fue eliminada' 
      }, { status: 400 })
    }

    const isAuthorized = clientOffer.clientId === session.user.id || 
                        clientOffer.offer.providerId === session.user.id

    if (!isAuthorized) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 403 })
    }

    // Obtener las negociaciones de cláusulas
    const negotiations = await prisma.clauseNegotiation.findMany({
      where: { clientOfferId },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ 
      success: true,
      clientOffer,
      negotiations
    })

  } catch (error) {
    console.error('Error fetching clause negotiations:', error)
    return NextResponse.json({ 
      error: 'Error interno del servidor' 
    }, { status: 500 })
  }
}
