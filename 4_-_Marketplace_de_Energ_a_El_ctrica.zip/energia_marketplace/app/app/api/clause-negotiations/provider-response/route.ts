
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || session.user.userType !== 'PROVIDER') {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const body = await request.json()
    const {
      clauseNegotiationId,
      action, // 'accept', 'reject', 'counter'
      providerResponse,
      providerResponseNote,
      finalAgreedValue
    } = body

    // Obtener la negociación de cláusula
    const clauseNegotiation = await prisma.clauseNegotiation.findUnique({
      where: { id: clauseNegotiationId },
      include: { 
        clientOffer: {
          include: {
            offer: true
          }
        }
      }
    })

    if (!clauseNegotiation) {
      return NextResponse.json({ error: 'Negociación no encontrada' }, { status: 404 })
    }

    // Verificar que la oferta aún exista
    if (!clauseNegotiation.clientOffer.offer) {
      return NextResponse.json({ 
        error: 'No se puede responder: la oferta original fue eliminada' 
      }, { status: 400 })
    }

    // Verificar que el usuario sea el proveedor de esta oferta
    if (clauseNegotiation.clientOffer.offer.providerId !== session.user.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 403 })
    }

    let newStatus: string
    let updateData: any = {
      providerResponse,
      providerResponseNote,
      lastUpdatedBy: session.user.id
    }

    switch (action) {
      case 'accept':
        newStatus = 'AGREED'
        updateData.finalAgreedValue = clauseNegotiation.clientProposedValue
        break
      case 'reject':
        newStatus = 'REJECTED'
        break
      case 'counter':
        newStatus = 'NEGOTIATING'
        updateData.finalAgreedValue = finalAgreedValue
        break
      default:
        return NextResponse.json({ error: 'Acción inválida' }, { status: 400 })
    }

    // Actualizar la negociación
    const updatedNegotiation = await prisma.clauseNegotiation.update({
      where: { id: clauseNegotiationId },
      data: {
        ...updateData,
        status: newStatus
      }
    })

    return NextResponse.json({ 
      success: true, 
      message: 'Respuesta guardada correctamente',
      negotiation: updatedNegotiation
    })

  } catch (error) {
    console.error('Error saving provider response:', error)
    return NextResponse.json({ 
      error: 'Error interno del servidor' 
    }, { status: 500 })
  }
}
