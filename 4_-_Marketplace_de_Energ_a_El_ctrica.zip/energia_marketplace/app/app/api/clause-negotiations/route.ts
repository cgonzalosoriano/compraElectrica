
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const body = await request.json()
    const {
      clientOfferId,
      clauseType,
      status,
      clientProposedValue,
      clientNegotiationNote,
      originalValue
    } = body

    // Verificar que el usuario sea el cliente de esta oferta
    const clientOffer = await prisma.clientOffer.findUnique({
      where: { id: clientOfferId },
      include: { client: true }
    })

    if (!clientOffer) {
      return NextResponse.json({ error: 'Oferta no encontrada' }, { status: 404 })
    }

    if (clientOffer.clientId !== session.user.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 403 })
    }

    // Crear o actualizar la negociación de la cláusula
    const clauseNegotiation = await prisma.clauseNegotiation.upsert({
      where: {
        clientOfferId_clauseType: {
          clientOfferId,
          clauseType
        }
      },
      update: {
        status,
        clientProposedValue,
        clientNegotiationNote,
        lastUpdatedBy: session.user.id
      },
      create: {
        clientOfferId,
        clauseType,
        originalValue,
        status,
        clientProposedValue,
        clientNegotiationNote,
        isClientInitiated: true,
        lastUpdatedBy: session.user.id
      }
    })

    return NextResponse.json({ 
      success: true, 
      message: 'Decisión de cláusula guardada correctamente',
      clauseNegotiation
    })

  } catch (error) {
    console.error('Error saving clause negotiation:', error)
    return NextResponse.json({ 
      error: 'Error interno del servidor' 
    }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const clientOfferId = searchParams.get('clientOfferId')

    if (!clientOfferId) {
      return NextResponse.json({ error: 'clientOfferId es requerido' }, { status: 400 })
    }

    // Verificar que el usuario tenga acceso a esta oferta
    const clientOffer = await prisma.clientOffer.findUnique({
      where: { id: clientOfferId },
      include: { 
        client: true,
        offer: {
          include: {
            provider: true
          }
        }
      }
    })

    if (!clientOffer) {
      return NextResponse.json({ error: 'Oferta no encontrada' }, { status: 404 })
    }

    if (!clientOffer.offer) {
      return NextResponse.json({ 
        error: 'No se puede crear negociación: la oferta original fue eliminada' 
      }, { status: 400 })
    }

    const isAuthorized = clientOffer.clientId === session.user.id || 
                        clientOffer.offer.providerId === session.user.id

    if (!isAuthorized) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 403 })
    }

    // Obtener las negociaciones de cláusulas
    const negotiations = await prisma.clauseNegotiation.findMany({
      where: { clientOfferId },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ 
      success: true,
      clientOffer,
      negotiations
    })

  } catch (error) {
    console.error('Error fetching clause negotiations:', error)
    return NextResponse.json({ 
      error: 'Error interno del servidor' 
    }, { status: 500 })
  }
}
