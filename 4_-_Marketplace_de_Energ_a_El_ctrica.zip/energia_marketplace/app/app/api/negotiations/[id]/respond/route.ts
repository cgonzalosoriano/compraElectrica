

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

// Responder a una negociación
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const negotiationId = params.id
    const body = await request.json()
    const { response, responseMessage } = body // response: 'ACCEPTED' | 'REJECTED' | 'COUNTER_OFFERED'

    if (!['ACCEPTED', 'REJECTED', 'COUNTER_OFFERED'].includes(response)) {
      return NextResponse.json({ error: 'Respuesta inválida' }, { status: 400 })
    }

    // Obtener el usuario actual
    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email }
    })

    if (!currentUser) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 })
    }

    // Obtener la negociación
    const negotiation = await prisma.negotiation.findUnique({
      where: { id: negotiationId },
      include: {
        contract: true
      }
    })

    if (!negotiation) {
      return NextResponse.json({ error: 'Negociación no encontrada' }, { status: 404 })
    }

    // Verificar que el usuario actual sea el destinatario de la negociación
    if (negotiation.recipientId !== currentUser.id) {
      return NextResponse.json({ error: 'No autorizado para responder a esta negociación' }, { status: 403 })
    }

    // Actualizar la negociación
    const updatedNegotiation = await prisma.negotiation.update({
      where: { id: negotiationId },
      data: {
        status: response as any,
        respondedAt: new Date(),
        responseMessage
      },
      include: {
        contract: true,
        proposer: { select: { id: true, name: true, companyName: true } },
        recipient: { select: { id: true, name: true, companyName: true } }
      }
    })

    // Si la propuesta fue aceptada, podemos actualizar el contrato o generar términos finales
    if (response === 'ACCEPTED') {
      // Aquí podrías actualizar el estado del contrato si es necesario
      await prisma.contract.update({
        where: { id: negotiation.contractId },
        data: {
          status: 'NEGOTIATING' // Listo para generar el contrato final
        }
      })
    }

    return NextResponse.json({ 
      success: true, 
      negotiation: updatedNegotiation,
      message: `Propuesta ${response.toLowerCase()} exitosamente` 
    })

  } catch (error) {
    console.error('Error responding to negotiation:', error)
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 })
  }
}
