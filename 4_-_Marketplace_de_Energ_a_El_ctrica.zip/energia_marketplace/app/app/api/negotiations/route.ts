

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

// Crear nueva negociación
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const body = await request.json()
    const {
      contractId,
      clientOfferId,
      recipientId,
      proposedEnergyPrice,
      proposedPowerPrice,
      proposedVolume,
      proposedTerm,
      proposedPaymentTerms,
      proposedGuarantees,
      proposedConditions,
      message
    } = body

    // Obtener el usuario actual
    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email }
    })

    if (!currentUser) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 })
    }

    // Verificar que el contrato existe y el usuario tiene permisos
    const contract = await prisma.contract.findUnique({
      where: { id: contractId },
      include: {
        clientOffer: true
      }
    })

    if (!contract) {
      return NextResponse.json({ error: 'Contrato no encontrado' }, { status: 404 })
    }

    // Verificar que el usuario actual sea el cliente o el proveedor del contrato
    if (contract.clientId !== currentUser.id && contract.providerId !== currentUser.id) {
      return NextResponse.json({ error: 'No autorizado para negociar este contrato' }, { status: 403 })
    }

    // Crear la negociación
    const negotiation = await prisma.negotiation.create({
      data: {
        contractId,
        clientOfferId,
        proposerId: currentUser.id,
        recipientId,
        proposedEnergyPrice,
        proposedPowerPrice,
        proposedVolume,
        proposedTerm,
        proposedPaymentTerms,
        proposedGuarantees,
        proposedConditions,
        message
      },
      include: {
        proposer: { select: { id: true, name: true, companyName: true } },
        recipient: { select: { id: true, name: true, companyName: true } }
      }
    })

    return NextResponse.json({ 
      success: true, 
      negotiation,
      message: 'Propuesta de negociación enviada exitosamente' 
    })

  } catch (error) {
    console.error('Error creating negotiation:', error)
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 })
  }
}

// Obtener negociaciones
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const contractId = searchParams.get('contractId')

    // Obtener el usuario actual
    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email }
    })

    if (!currentUser) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 })
    }

    let whereClause: any = {
      OR: [
        { proposerId: currentUser.id },
        { recipientId: currentUser.id }
      ]
    }

    if (contractId) {
      whereClause.contractId = contractId
    }

    const negotiations = await prisma.negotiation.findMany({
      where: whereClause,
      include: {
        contract: {
          include: {
            offer: true,
            client: { select: { id: true, name: true, companyName: true } },
            provider: { select: { id: true, name: true, companyName: true } }
          }
        },
        proposer: { select: { id: true, name: true, companyName: true } },
        recipient: { select: { id: true, name: true, companyName: true } }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ negotiations })

  } catch (error) {
    console.error('Error fetching negotiations:', error)
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 })
  }
}
