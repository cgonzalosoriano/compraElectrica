
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.userType !== 'PROVIDER') {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    // Obtener solicitudes activas que no hayan vencido
    const quoteRequests = await prisma.quoteRequest.findMany({
      where: {
        status: 'ACTIVE',
        deadline: {
          gte: new Date(),
        },
      },
      include: {
        client: {
          select: {
            id: true,
            name: true,
            companyName: true,
            distributorName: true,
            region: true,
          },
        },
        periods: {
          orderBy: { periodNumber: 'asc' },
        },
        clauses: true,
        _count: {
          select: { 
            responses: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    // Filtrar solo las solicitudes a las que el proveedor NO ha respondido
    const quoteRequestsWithoutResponse = await Promise.all(
      quoteRequests.map(async (request) => {
        const existingResponse = await prisma.quoteResponse.findUnique({
          where: {
            quoteRequestId_providerId: {
              quoteRequestId: request.id,
              providerId: session.user.id,
            },
          },
        });

        // Solo incluir si NO tiene respuesta del proveedor
        if (existingResponse) {
          return null;
        }

        return {
          ...request,
          hasResponded: false,
          myResponseStatus: null,
          _count: {
            ...request._count,
            providerResponses: 0,
          },
        };
      })
    );

    // Filtrar los null (solicitudes con respuesta)
    const filteredRequests = quoteRequestsWithoutResponse.filter(r => r !== null);

    return NextResponse.json({
      quoteRequests: filteredRequests,
    });
  } catch (error) {
    console.error('Error al obtener solicitudes disponibles:', error);
    return NextResponse.json(
      { error: 'Error al obtener las solicitudes' },
      { status: 500 }
    );
  }
}
