

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '../../../../lib/auth';
import { prisma } from '../../../../lib/db';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.userType !== 'PROVIDER') {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    // Obtener todas las respuestas del proveedor con ofertas realizadas (excluyendo solo estados finales definitivos)
    const myResponses = await prisma.quoteResponse.findMany({
      where: {
        providerId: session.user.id,
        status: {
          notIn: ['WITHDRAWN'], // Solo excluir respuestas retiradas
        },
      },
      include: {
        quoteRequest: {
          include: {
            client: {
              select: {
                id: true,
                name: true,
                companyName: true,
                distributorName: true,
                region: true,
              },
            },
            periods: {
              orderBy: { periodNumber: 'asc' },
            },
            clauses: true,
            _count: {
              select: { 
                responses: true,
              },
            },
          },
        },
        periods: {
          orderBy: { periodNumber: 'asc' },
        },
        clauseResponses: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    // Formatear la respuesta para que sea más fácil de usar en el frontend
    const formattedResponses = myResponses.map(response => ({
      id: response.id,
      quoteRequestId: response.quoteRequestId,
      status: response.status,
      totalEstimated: response.totalEstimated,
      energyPricePerMWh: response.energyPricePerMWh,
      powerPricePerKW: response.powerPricePerKW,
      viewedByClient: response.viewedByClient,
      createdAt: response.createdAt,
      updatedAt: response.updatedAt,
      quoteRequest: {
        ...response.quoteRequest,
        myResponseStatus: response.status,
        _count: {
          ...response.quoteRequest._count,
          providerResponses: 1,
        },
      },
      myResponse: {
        id: response.id,
        status: response.status,
        energyPricePerMWh: response.energyPricePerMWh,
        powerPricePerKW: response.powerPricePerKW,
        totalEstimated: response.totalEstimated,
        viewedByClient: response.viewedByClient,
        paymentTerms: response.paymentTerms,
        guaranteesRequired: response.guaranteesRequired,
        deliveryNode: response.deliveryNode,
        generationSource: response.generationSource,
        otherConditions: response.otherConditions,
        providerComments: response.providerComments,
        periods: response.periods,
        clauseResponses: response.clauseResponses,
        createdAt: response.createdAt,
        updatedAt: response.updatedAt,
      },
    }));

    return NextResponse.json({
      responses: formattedResponses,
    });
  } catch (error) {
    console.error('Error al obtener mis ofertas:', error);
    return NextResponse.json(
      { error: 'Error al obtener las ofertas' },
      { status: 500 }
    );
  }
}

