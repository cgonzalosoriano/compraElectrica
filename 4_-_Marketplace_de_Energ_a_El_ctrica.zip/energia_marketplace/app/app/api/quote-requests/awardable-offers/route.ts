
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

// GET /api/quote-requests/awardable-offers - Obtener ofertas con todas las cláusulas aceptadas
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user || user.userType !== 'CLIENT') {
      return NextResponse.json(
        { error: 'Solo los clientes pueden ver ofertas adjudicables' },
        { status: 403 }
      );
    }

    // Obtener todas las respuestas de cotización del cliente con revisiones completas
    const awardableOffers = await prisma.quoteResponse.findMany({
      where: {
        quoteRequest: {
          clientId: user.id,
        },
        status: {
          in: ['SUBMITTED', 'UPDATED'], // No mostrar ofertas ya aceptadas o rechazadas
        },
        review: {
          allClausesAccepted: true,
        },
      },
      include: {
        provider: {
          select: {
            id: true,
            name: true,
            companyName: true,
            email: true,
          },
        },
        quoteRequest: {
          select: {
            id: true,
            title: true,
            description: true,
            status: true,
            deadline: true,
            createdAt: true,
            termMonths: true,
            preferredEnergySource: true,
          },
        },
        review: {
          select: {
            allClausesAccepted: true,
            allClausesReviewed: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    return NextResponse.json({
      success: true,
      offers: awardableOffers,
    });
  } catch (error) {
    console.error('Error al obtener ofertas adjudicables:', error);
    return NextResponse.json(
      { error: 'Error al obtener ofertas adjudicables' },
      { status: 500 }
    );
  }
}
