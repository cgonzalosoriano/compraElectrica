
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const quoteRequestId = params.id;

    const quoteRequest = await prisma.quoteRequest.findUnique({
      where: { id: quoteRequestId },
      include: {
        periods: { orderBy: { periodNumber: 'asc' } },
        clauses: true,
        client: {
          select: {
            id: true,
            name: true,
            companyName: true,
          },
        },
        _count: {
          select: { responses: true },
        },
      },
    });

    if (!quoteRequest) {
      return NextResponse.json(
        { error: 'Solicitud no encontrada' },
        { status: 404 }
      );
    }

    // Verificar autorización
    if (session.user.userType === 'CLIENT' && quoteRequest.clientId !== session.user.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 403 }
      );
    }

    return NextResponse.json({ quoteRequest });
  } catch (error) {
    console.error('Error al obtener solicitud:', error);
    return NextResponse.json(
      { error: 'Error al obtener la solicitud' },
      { status: 500 }
      );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.userType !== 'CLIENT') {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const quoteRequestId = params.id;
    const body = await request.json();

    // Verificar que la solicitud pertenezca al cliente
    const existingRequest = await prisma.quoteRequest.findUnique({
      where: { id: quoteRequestId },
    });

    if (!existingRequest) {
      return NextResponse.json(
        { error: 'Solicitud no encontrada' },
        { status: 404 }
      );
    }

    if (existingRequest.clientId !== session.user.id) {
      return NextResponse.json(
        { error: 'No autorizado para editar esta solicitud' },
        { status: 403 }
      );
    }

    if (existingRequest.status !== 'ACTIVE') {
      return NextResponse.json(
        { error: 'Solo se pueden editar solicitudes activas' },
        { status: 400 }
      );
    }

    const {
      title,
      description,
      termMonths,
      startDate,
      paymentTerms,
      guaranteesOffered,
      preferredEnergySource,
      requiresCertificate,
      deliveryNode,
      userNumber,
      distributorName,
      region,
      deadline,
      periods,
      clauses,
    } = body;

    // Actualizar la solicitud
    const updatedRequest = await prisma.quoteRequest.update({
      where: { id: quoteRequestId },
      data: {
        title,
        description,
        termMonths,
        startDate: startDate ? new Date(startDate) : null,
        paymentTerms,
        guaranteesOffered,
        preferredEnergySource,
        deliveryNode,
        userNumber,
        distributorName,
        region,
        deadline: deadline ? new Date(deadline) : undefined,
      },
    });

    // Eliminar períodos antiguos y crear nuevos si se proporcionaron
    if (periods && periods.length > 0) {
      await prisma.quoteRequestPeriod.deleteMany({
        where: { quoteRequestId },
      });

      await prisma.quoteRequestPeriod.createMany({
        data: periods.map((p: any, index: number) => ({
          quoteRequestId,
          periodNumber: index + 1,
          periodName: p.periodName,
          powerKW: p.powerKW,
          energyMWh: p.energyMWh,
        })),
      });
    }

    // Eliminar cláusulas antiguas y crear nuevas si se proporcionaron
    if (clauses && clauses.length > 0) {
      await prisma.quoteRequestClause.deleteMany({
        where: { quoteRequestId },
      });

      await prisma.quoteRequestClause.createMany({
        data: clauses.map((c: any) => ({
          quoteRequestId,
          clauseName: c.clauseName,
          clauseDescription: c.clauseDescription,
          isRequired: c.isRequired || false,
        })),
      });
    }

    // Notificar a proveedores que ya respondieron
    const responses = await prisma.quoteResponse.findMany({
      where: { quoteRequestId },
      select: { providerId: true },
    });

    const notificationsData = responses.map(response => ({
      userId: response.providerId,
      type: 'QUOTE_REQUEST_CLOSED' as const,
      title: 'Solicitud de cotización actualizada',
      message: `La solicitud "${title}" ha sido actualizada por el cliente.`,
      quoteRequestId,
    }));

    if (notificationsData.length > 0) {
      await prisma.notification.createMany({
        data: notificationsData,
      });
    }

    return NextResponse.json({
      message: 'Solicitud actualizada exitosamente',
      quoteRequest: updatedRequest,
    });
  } catch (error) {
    console.error('Error al actualizar solicitud:', error);
    return NextResponse.json(
      { error: 'Error al actualizar la solicitud' },
      { status: 500 }
    );
  }
}
