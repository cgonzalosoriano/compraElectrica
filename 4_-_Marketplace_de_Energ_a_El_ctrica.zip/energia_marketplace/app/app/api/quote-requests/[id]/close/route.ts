
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.userType !== 'CLIENT') {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const quoteRequestId = params.id;

    // Verificar que la solicitud pertenezca al cliente
    const quoteRequest = await prisma.quoteRequest.findUnique({
      where: { id: quoteRequestId },
    });

    if (!quoteRequest) {
      return NextResponse.json(
        { error: 'Solicitud no encontrada' },
        { status: 404 }
      );
    }

    if (quoteRequest.clientId !== session.user.id) {
      return NextResponse.json(
        { error: 'No autorizado para cerrar esta solicitud' },
        { status: 403 }
      );
    }

    if (quoteRequest.status !== 'ACTIVE') {
      return NextResponse.json(
        { error: 'Solo se pueden cerrar solicitudes activas' },
        { status: 400 }
      );
    }

    // Cerrar la solicitud
    const updatedRequest = await prisma.quoteRequest.update({
      where: { id: quoteRequestId },
      data: { status: 'CLOSED' },
    });

    // Crear notificaciones para los proveedores que respondieron
    const responses = await prisma.quoteResponse.findMany({
      where: { quoteRequestId },
      select: { providerId: true },
    });

    const notificationsData = responses.map(response => ({
      userId: response.providerId,
      type: 'QUOTE_REQUEST_CLOSED' as const,
      title: 'Solicitud de cotización cerrada',
      message: `La solicitud "${quoteRequest.title}" ha sido cerrada por el cliente.`,
      quoteRequestId,
    }));

    if (notificationsData.length > 0) {
      await prisma.notification.createMany({
        data: notificationsData,
      });
    }

    return NextResponse.json({
      message: 'Solicitud cerrada exitosamente',
      quoteRequest: updatedRequest,
    });
  } catch (error) {
    console.error('Error al cerrar solicitud:', error);
    return NextResponse.json(
      { error: 'Error al cerrar la solicitud' },
      { status: 500 }
    );
  }
}
