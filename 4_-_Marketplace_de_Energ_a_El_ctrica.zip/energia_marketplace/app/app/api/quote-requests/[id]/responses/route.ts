
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const quoteRequestId = params.id;

    // Verificar que la solicitud existe y pertenece al cliente o es accesible para proveedores
    const quoteRequest = await prisma.quoteRequest.findUnique({
      where: { id: quoteRequestId },
      include: {
        periods: { orderBy: { periodNumber: 'asc' } },
        clauses: true,
        client: {
          select: {
            id: true,
            name: true,
            companyName: true,
            email: true,
          },
        },
      },
    });

    if (!quoteRequest) {
      return NextResponse.json(
        { error: 'Solicitud no encontrada' },
        { status: 404 }
      );
    }

    // Verificar autorización
    if (session.user.userType === 'CLIENT' && quoteRequest.clientId !== session.user.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 403 }
      );
    }

    // Obtener las respuestas
    const responses = await prisma.quoteResponse.findMany({
      where: { quoteRequestId },
      include: {
        provider: {
          select: {
            id: true,
            name: true,
            companyName: true,
            email: true,
            phone: true,
          },
        },
        periods: { orderBy: { periodNumber: 'asc' } },
        review: true,
        clauseResponses: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      quoteRequest,
      responses,
    });
  } catch (error) {
    console.error('Error al obtener respuestas:', error);
    return NextResponse.json(
      { error: 'Error al obtener las respuestas' },
      { status: 500 }
    );
  }
}
