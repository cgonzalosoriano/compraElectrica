
import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { PrismaClient } from "@prisma/client"

export const dynamic = "force-dynamic"

const prisma = new PrismaClient()

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || session.user.userType !== 'CLIENT') {
      return NextResponse.json(
        { error: "No autorizado" },
        { status: 401 }
      )
    }

    const body = await request.json()
    const {
      title,
      description,
      termMonths,
      startMonth,
      periods,
      paymentTerms,
      guarantees,
      deliveryNode,
      energySources,
      requiresRenewableCertificate,
      deadline,
      customClauses
    } = body

    // Validaciones básicas
    if (!title || !termMonths || !deadline) {
      return NextResponse.json(
        { error: "Faltan datos requeridos" },
        { status: 400 }
      )
    }

    // Construir la preferencia de fuentes de energía
    const energySourcePreference = energySources?.length > 0 
      ? energySources.join(', ')
      : 'todas';

    // Crear la solicitud de cotización con sus relaciones
    const quoteRequest = await prisma.quoteRequest.create({
      data: {
        clientId: session.user.id,
        title,
        description: description || null,
        termMonths: parseInt(termMonths),
        startDate: startMonth ? new Date(2025, parseInt(startMonth), 1) : null,
        paymentTerms: paymentTerms || null,
        guaranteesOffered: guarantees || null,
        preferredEnergySource: energySourcePreference + (requiresRenewableCertificate ? ' (con certificado renovable I-REC)' : ''),
        deliveryNode: deliveryNode || null,
        deadline: new Date(deadline),
        status: 'ACTIVE',
        
        // Crear períodos relacionados
        periods: {
          create: periods?.map((period: any, index: number) => ({
            periodNumber: index + 1,
            periodName: period.month || `Mes ${index + 1}`,
            powerKW: period.powerMW ? parseFloat(period.powerMW) * 1000 : null, // Convertir MW a kW
            energyMWh: period.energyMWh ? parseFloat(period.energyMWh) : null
          })) || []
        },
        
        // Crear cláusulas personalizadas
        clauses: {
          create: customClauses?.map((clause: any) => ({
            clauseName: clause.name,
            clauseDescription: clause.description,
            isRequired: clause.isRequired || false
          })) || []
        }
      },
      include: {
        periods: true,
        clauses: true,
        client: {
          select: {
            id: true,
            name: true,
            companyName: true,
            email: true
          }
        }
      }
    })

    return NextResponse.json(
      { 
        quoteRequest,
        message: "Solicitud de cotización creada exitosamente"
      },
      { status: 201 }
    )
  } catch (error) {
    console.error("Error al crear solicitud de cotización:", error)
    return NextResponse.json(
      { error: "Error interno del servidor", details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session) {
      return NextResponse.json(
        { error: "No autorizado" },
        { status: 401 }
      )
    }

    // Si es cliente, obtener solo sus solicitudes
    const where = session.user.userType === 'CLIENT' 
      ? { clientId: session.user.id }
      : {}; // Si es proveedor o admin, ver todas

    const quoteRequests = await prisma.quoteRequest.findMany({
      where,
      include: {
        client: {
          select: {
            id: true,
            name: true,
            companyName: true,
            email: true
          }
        },
        periods: {
          orderBy: { periodNumber: 'asc' }
        },
        clauses: true,
        responses: {
          include: {
            provider: {
              select: {
                id: true,
                name: true,
                companyName: true
              }
            }
          }
        },
        _count: {
          select: {
            responses: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ quoteRequests })
  } catch (error) {
    console.error("Error al obtener solicitudes de cotización:", error)
    return NextResponse.json(
      { error: "Error interno del servidor" },
      { status: 500 }
    )
  }
}
