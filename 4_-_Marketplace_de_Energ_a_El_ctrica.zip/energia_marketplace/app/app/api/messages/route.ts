
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const { clientOfferId, message } = await request.json()

    if (!clientOfferId || !message) {
      return NextResponse.json({ error: 'ID de oferta de cliente y mensaje requeridos' }, { status: 400 })
    }

    // Obtener la oferta del cliente para validar acceso
    const clientOffer = await prisma.clientOffer.findUnique({
      where: { id: clientOfferId },
      include: {
        client: true,
        offer: {
          include: {
            provider: true
          }
        }
      }
    })

    if (!clientOffer) {
      return NextResponse.json({ error: 'Oferta de cliente no encontrada' }, { status: 404 })
    }

    // Verificar que el usuario actual sea el proveedor de la oferta
    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email }
    })

    if (!clientOffer.offer) {
      return NextResponse.json({ 
        error: 'No se puede enviar mensaje: la oferta original fue eliminada' 
      }, { status: 400 })
    }

    if (!currentUser || currentUser.id !== clientOffer.offer.providerId) {
      return NextResponse.json({ error: 'No autorizado para enviar mensaje en esta oferta' }, { status: 403 })
    }

    // Crear el mensaje
    const messageRecord = await prisma.message.create({
      data: {
        senderId: currentUser.id,
        recipientId: clientOffer.clientId,
        clientOfferId: clientOfferId,
        content: message,
        messageType: 'NEGOTIATION'
      }
    })

    return NextResponse.json({ 
      success: true, 
      messageId: messageRecord.id,
      message: 'Mensaje enviado exitosamente' 
    })

  } catch (error) {
    console.error('Error sending message:', error)
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const url = new URL(request.url)
    const clientOfferId = url.searchParams.get('clientOfferId')

    if (!clientOfferId) {
      return NextResponse.json({ error: 'ID de oferta de cliente requerido' }, { status: 400 })
    }

    // Obtener mensajes de la oferta del cliente
    const messages = await prisma.message.findMany({
      where: { clientOfferId: clientOfferId },
      include: {
        sender: {
          select: { id: true, name: true, email: true, userType: true, companyName: true }
        },
        recipient: {
          select: { id: true, name: true, email: true, userType: true, companyName: true }
        }
      },
      orderBy: { createdAt: 'asc' }
    })

    return NextResponse.json({ messages })

  } catch (error) {
    console.error('Error fetching messages:', error)
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 })
  }
}
