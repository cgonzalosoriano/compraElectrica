
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const clientOfferId = searchParams.get('clientOfferId');

    if (!clientOfferId) {
      return NextResponse.json({ error: 'clientOfferId es requerido' }, { status: 400 });
    }

    // Buscar el contrato asociado al clientOfferId
    const contract = await prisma.contract.findFirst({
      where: {
        clientOfferId: clientOfferId
      },
      include: {
        client: true,
        provider: true,
        clientOffer: true,
        offer: true
      }
    });

    if (!contract) {
      return NextResponse.json({ error: 'Contrato no encontrado' }, { status: 404 });
    }

    // Verificar que el usuario sea parte del contrato
    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email }
    });

    if (!currentUser || (contract.clientId !== currentUser.id && contract.providerId !== currentUser.id)) {
      return NextResponse.json({ error: 'No tienes permiso para ver este contrato' }, { status: 403 });
    }

    return NextResponse.json({ contract });

  } catch (error) {
    console.error('Error al obtener contrato:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
