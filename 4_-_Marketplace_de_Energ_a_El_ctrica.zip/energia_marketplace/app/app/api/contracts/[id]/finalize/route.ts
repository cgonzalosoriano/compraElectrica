

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const contractId = params.id

    // Obtener el usuario actual
    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email }
    })

    if (!currentUser) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 })
    }

    // Obtener el contrato con sus negociaciones
    const contract = await prisma.contract.findUnique({
      where: { id: contractId },
      include: {
        client: true,
        provider: true,
        offer: true,
        clientOffer: true,
        negotiations: {
          where: { status: 'ACCEPTED' },
          orderBy: { createdAt: 'desc' },
          take: 1
        }
      }
    })

    if (!contract) {
      return NextResponse.json({ error: 'Contrato no encontrado' }, { status: 404 })
    }

    // Verificar que el usuario actual sea el cliente o el proveedor del contrato
    if (contract.clientId !== currentUser.id && contract.providerId !== currentUser.id) {
      return NextResponse.json({ error: 'No autorizado para finalizar este contrato' }, { status: 403 })
    }

    // Verificar que haya al menos una negociación aceptada
    if (contract.negotiations.length === 0) {
      return NextResponse.json({ error: 'No hay términos negociados aceptados para finalizar el contrato' }, { status: 400 })
    }

    const acceptedNegotiation = contract.negotiations[0]

    // Generar términos finales del contrato
    const finalTerms = generateFinalContractTerms(contract, acceptedNegotiation)

    // Actualizar el contrato a estado DRAFT (listo para firma)
    const updatedContract = await prisma.contract.update({
      where: { id: contractId },
      data: {
        status: 'NEGOTIATING',
        terms: finalTerms
      }
    })

    return NextResponse.json({ 
      success: true, 
      contract: updatedContract,
      message: 'Contrato finalizado exitosamente y listo para firma' 
    })

  } catch (error) {
    console.error('Error finalizing contract:', error)
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 })
  }
}

function generateFinalContractTerms(contract: any, acceptedNegotiation: any): string {
  const currentDate = new Date().toLocaleDateString('es-AR')
  
  return `CONTRATO DE SUMINISTRO DE ENERGÍA ELÉCTRICA

FECHA: ${currentDate}

PARTES:
PROVEEDOR: ${contract.provider?.companyName || 'N/A'}
EMAIL: ${contract.provider?.email}
TELÉFONO: ${contract.provider?.phone || 'N/A'}

CLIENTE: ${contract.client?.companyName || 'N/A'}
EMAIL: ${contract.client?.email}
TELÉFONO: ${contract.client?.phone || 'N/A'}

TÉRMINOS ACORDADOS DEL CONTRATO:

1. CONDICIONES TÉCNICAS Y COMERCIALES:
   - Precio de Energía: $${acceptedNegotiation.proposedEnergyPrice || contract.offer?.energyPrice} por MWh
   - Precio de Potencia: $${acceptedNegotiation.proposedPowerPrice || contract.offer?.powerPrice} por kW-mes
   - Volumen Acordado: ${acceptedNegotiation.proposedVolume || contract.clientOffer?.requestedVolume || contract.offer?.availableVolume} MWh
   - Nodo de Entrega: ${contract.offer?.deliveryNode}
   - Fuente de Generación: ${contract.offer?.generationSource}
   - Plazo: ${acceptedNegotiation.proposedTerm || contract.offer?.term} meses

2. DATOS DEL SUMINISTRO:
   - Número de Usuario: ${contract.clientOffer?.userNumber || 'N/A'}
   - Distribuidora: ${contract.clientOffer?.distributorName || 'N/A'}
   - Región: ${contract.clientOffer?.region || 'N/A'}
   - Dirección de Suministro: ${contract.clientOffer?.address || 'N/A'}
   - Tipo de Tarifa: ${contract.clientOffer?.tariffType || 'N/A'}

3. TÉRMINOS DE PAGO:
   - Forma de Pago: ${acceptedNegotiation.proposedPaymentTerms || contract.offer?.paymentTerms}
   - Garantías: ${acceptedNegotiation.proposedGuarantees || contract.offer?.guarantees}

4. CONDICIONES ESPECIALES:
   ${acceptedNegotiation.proposedConditions || contract.offer?.otherConditions || 'Ninguna condición especial acordada'}

5. TÉRMINOS Y CONDICIONES GENERALES:
   - El suministro se realizará según las especificaciones acordadas
   - El pago se realizará según los términos establecidos
   - La comisión de la plataforma (2%) será aplicada según corresponda
   - Cualquier modificación deberá ser acordada por escrito por ambas partes
   - Este contrato está sujeto a las leyes de la República Argentina
   - Vigencia: desde la fecha de firma por ${acceptedNegotiation.proposedTerm || contract.offer?.term} meses

6. RESOLUCIÓN DE DISPUTAS:
   - Las disputas serán resueltas mediante mediación
   - En caso de no llegar a acuerdo, se someterán a arbitraje
   - Jurisdicción: Tribunales de la Ciudad Autónoma de Buenos Aires

FIRMAS:

_________________________        _________________________
Proveedor                        Cliente
${contract.provider?.companyName}      ${contract.client?.companyName}

Fecha: ${currentDate}

NOTA: Este contrato ha sido generado tras proceso de negociación en la plataforma.
Para validación legal, consulte con un abogado especializado en contratos energéticos.`
}
