
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const contractId = params.id;
    const { signedDocumentPath } = await request.json();

    if (!signedDocumentPath) {
      return NextResponse.json({ error: 'Ruta del documento requerida' }, { status: 400 });
    }

    // Buscar el usuario actual
    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email }
    });

    if (!currentUser) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });
    }

    // Buscar el ClientOffer en lugar de Contract (evita problemas de schema)
    const clientOffer = await prisma.clientOffer.findUnique({
      where: { id: contractId },
      include: {
        client: true,
        offer: {
          include: {
            provider: true
          }
        }
      }
    });

    if (!clientOffer) {
      return NextResponse.json({ error: 'Contrato no encontrado' }, { status: 404 });
    }

    // Determinar quién está firmando
    const isClient = clientOffer.clientId === currentUser.id;
    const isProvider = clientOffer.offer?.providerId === currentUser.id;

    if (!isClient && !isProvider) {
      return NextResponse.json({ error: 'No tienes permiso para firmar este contrato' }, { status: 403 });
    }

    // Actualizar el clientOffer con la firma
    if (isClient) {
      await prisma.clientOffer.update({
        where: { id: contractId },
        data: {
          clientSignedDocumentPath: signedDocumentPath,
          clientSignedAt: new Date()
        }
      });
    } else if (isProvider) {
      await prisma.clientOffer.update({
        where: { id: contractId },
        data: {
          providerSignedDocumentPath: signedDocumentPath,
          providerSignedAt: new Date()
        }
      });
    }

    // Verificar si ambas partes han firmado
    const updatedClientOffer = await prisma.clientOffer.findUnique({
      where: { id: contractId }
    });

    const bothPartiesSigned = updatedClientOffer?.clientSignedDocumentPath && 
                              updatedClientOffer?.providerSignedDocumentPath;

    if (bothPartiesSigned) {
      // Actualizar el estado del clientOffer a COMPLETED
      await prisma.clientOffer.update({
        where: { id: contractId },
        data: { status: 'COMPLETED' }
      });

      return NextResponse.json({
        message: '¡Contrato firmado por ambas partes! El contrato está ahora completado.',
        bothPartiesSigned: true
      });
    } else {
      return NextResponse.json({
        message: 'Tu firma ha sido registrada. Esperando la firma de la otra parte.',
        bothPartiesSigned: false
      });
    }

  } catch (error) {
    console.error('Error signing contract:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
