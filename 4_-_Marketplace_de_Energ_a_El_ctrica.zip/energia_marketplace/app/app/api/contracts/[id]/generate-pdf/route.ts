
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import { jsPDF } from 'jspdf';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const contractId = params.id;

    // Buscar el usuario actual
    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email }
    });

    if (!currentUser) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });
    }

    // Primero buscar en clientOffer
    let clientOffer = await prisma.clientOffer.findFirst({
      where: {
        id: contractId,
        OR: [
          { clientId: currentUser.id },
          { offer: { providerId: currentUser.id } }
        ]
      },
      include: {
        client: true,
        offer: { include: { provider: true } }
      }
    });

    // Si no se encuentra, buscar en Contract
    if (!clientOffer) {
      const contract = await prisma.contract.findFirst({
        where: {
          id: contractId,
          OR: [
            { clientId: currentUser.id },
            { providerId: currentUser.id }
          ]
        },
        include: {
          client: true,
          provider: true,
          offer: true,
          clientOffer: true
        }
      });

      if (!contract) {
        return NextResponse.json({ error: 'Contrato no encontrado' }, { status: 404 });
      }

      // Extraer datos de precios y términos
      let energyPrice = 0;
      let powerPrice = 0;
      let term = 0;
      let volume = 0;

      if (contract.offer) {
        energyPrice = contract.offer.energyPrice;
        powerPrice = contract.offer.powerPrice;
        term = contract.offer.term;
        volume = contract.clientOffer?.requestedVolume || contract.offer.availableVolume;
      } else {
        // Si no hay offer (viene de cotización), extraer del contract.terms
        const termsText = contract.terms || '';
        
        const energyMatch = termsText.match(/Precio Energía: \$([0-9.]+)\/MWh/);
        if (energyMatch) energyPrice = parseFloat(energyMatch[1]);
        
        const powerMatch = termsText.match(/Precio Potencia: \$([0-9.]+)\/kW-mes/);
        if (powerMatch) powerPrice = parseFloat(powerMatch[1]);
        
        const volumeMatch = termsText.match(/Volumen Total: ([0-9.]+) MWh/);
        if (volumeMatch) volume = parseFloat(volumeMatch[1]);
        
        const termMatch = termsText.match(/Plazo: (\d+) meses/);
        if (termMatch) term = parseInt(termMatch[1]);
      }

      // Generar PDF desde Contract
      const doc = new jsPDF();
      doc.setFontSize(20);
      doc.text('Contrato de Suministro Eléctrico', 20, 30);
      
      doc.setFontSize(12);
      doc.text(`Cliente: ${contract.client.companyName || contract.client.name || 'N/A'}`, 20, 50);
      doc.text(`Proveedor: ${contract.provider.companyName || contract.provider.name || 'N/A'}`, 20, 60);
      doc.text(`Fecha: ${new Date().toLocaleDateString('es-AR')}`, 20, 70);
      doc.text(`ID del Contrato: ${contractId}`, 20, 80);
      
      doc.text(`Precio de Energía: $${energyPrice}/MWh`, 20, 100);
      doc.text(`Precio de Potencia: $${powerPrice}/kW-mes`, 20, 110);
      doc.text(`Plazo: ${term} meses`, 20, 120);
      doc.text(`Volumen: ${volume} MWh`, 20, 130);

      doc.text(`Estado: ${contract.status}`, 20, 150);
      
      // Agregar términos completos con saltos de línea
      const termsLines = doc.splitTextToSize(contract.terms || 'N/A', 170);
      doc.text('Términos:', 20, 160);
      doc.text(termsLines, 20, 170);

      const pdfBuffer = Buffer.from(doc.output('arraybuffer'));

      return new NextResponse(pdfBuffer, {
        headers: {
          'Content-Type': 'application/pdf',
          'Content-Disposition': `attachment; filename="contrato-${contractId}.pdf"`
        }
      });
    }

    // Si la oferta fue eliminada, mostrar error
    if (!clientOffer.offer) {
      return NextResponse.json(
        { error: 'La oferta asociada a este contrato ya no existe' },
        { status: 404 }
      );
    }

    // Generar PDF desde ClientOffer
    const doc = new jsPDF();
    doc.setFontSize(20);
    doc.text('Contrato de Suministro Eléctrico', 20, 30);
    
    doc.setFontSize(12);
    doc.text(`Cliente: ${clientOffer.client.companyName || clientOffer.client.name || 'N/A'}`, 20, 50);
    doc.text(`Proveedor: ${clientOffer.offer.provider?.companyName || clientOffer.offer.provider?.name || 'N/A'}`, 20, 60);
    doc.text(`Fecha: ${new Date().toLocaleDateString('es-AR')}`, 20, 70);
    doc.text(`ID del Contrato: ${contractId}`, 20, 80);
    
    doc.text(`Precio de Energía: $${clientOffer.offer.energyPrice}/MWh`, 20, 100);
    doc.text(`Precio de Potencia: $${clientOffer.offer.powerPrice}/kW-mes`, 20, 110);
    doc.text(`Plazo: ${clientOffer.offer.term} meses`, 20, 120);
    doc.text(`Volumen: ${clientOffer.requestedVolume || clientOffer.offer.availableVolume} MWh`, 20, 130);

    const pdfBuffer = Buffer.from(doc.output('arraybuffer'));

    return new NextResponse(pdfBuffer, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="contrato-${contractId}.pdf"`
      }
    });

  } catch (error) {
    console.error('Error al generar PDF:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
