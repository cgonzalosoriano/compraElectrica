
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const contractId = params.id;

    // Buscar el usuario actual
    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email }
    });

    if (!currentUser) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });
    }

    // Determinar si el usuario es cliente o proveedor
    const userIsClient = currentUser.userType === 'CLIENT';
    const userIsProvider = currentUser.userType === 'PROVIDER';

    // Buscar en ClientOffer en lugar de Contract (evita problemas de schema)
    const clientOffer = await prisma.clientOffer.findFirst({
      where: {
        id: contractId,
        OR: [
          { clientId: currentUser.id },
          { offer: { providerId: currentUser.id } }
        ]
      },
      include: {
        client: true,
        offer: {
          include: {
            provider: true
          }
        }
      }
    });

    if (!clientOffer) {
      return NextResponse.json({ error: 'Contrato no encontrado' }, { status: 404 });
    }

    // Información sobre las firmas (usar ClientOffer)
    const clientSigned = !!clientOffer.clientSignedDocumentPath;
    const providerSigned = !!clientOffer.providerSignedDocumentPath;
    const isCurrentUserClient = clientOffer.clientId === currentUser.id;
    const isCurrentUserProvider = clientOffer.offer?.providerId === currentUser.id;
    
    // Determinar qué documentos están disponibles para descargar
    const canDownloadClientSignedDoc = clientSigned && isCurrentUserProvider;
    const canDownloadProviderSignedDoc = providerSigned && isCurrentUserClient;

    // Extraer datos de precios y términos
    let energyPrice = 0;
    let powerPrice = 0;
    let term = 0;
    let volume = 0;
    let providerName = clientOffer.offer?.provider?.companyName || clientOffer.offer?.provider?.name || 'N/A';

    // Si hay offer, usar esos datos
    if (clientOffer.offer) {
      energyPrice = clientOffer.offer.energyPrice;
      powerPrice = clientOffer.offer.powerPrice;
      term = clientOffer.offer.term;
      volume = clientOffer.requestedVolume || clientOffer.offer.availableVolume;
    }

    // Retornar datos del ClientOffer
    return NextResponse.json({
      type: 'contract',
      id: clientOffer.id,
      clientName: clientOffer.client.companyName || clientOffer.client.name || 'N/A',
      providerName: providerName,
      date: new Date().toLocaleDateString('es-AR', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      }),
      energyPrice,
      powerPrice,
      term,
      volume,
      status: clientOffer.status,
      terms: 'Términos y condiciones estándar del mercado energético argentino',
      startDate: clientOffer.createdAt?.toLocaleDateString('es-AR') || 'A convenir',
      endDate: 'A convenir según términos del contrato',
      // Información de firmas
      signatures: {
        clientSigned,
        providerSigned,
        clientSignedAt: clientOffer.clientSignedAt?.toLocaleDateString('es-AR'),
        providerSignedAt: clientOffer.providerSignedAt?.toLocaleDateString('es-AR'),
        isCurrentUserClient,
        isCurrentUserProvider,
        canDownloadClientSignedDoc,
        canDownloadProviderSignedDoc,
        bothPartiesSigned: clientSigned && providerSigned
      }
    });

  } catch (error) {
    console.error('Error al obtener datos del contrato:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
