
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { PrismaClient } from '@prisma/client'
import { getSignedUrl } from '@aws-sdk/s3-request-presigner'
import { GetObjectCommand } from '@aws-sdk/client-s3'
import { createS3Client } from '@/lib/aws-config'

const prisma = new PrismaClient()

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'No autenticado' },
        { status: 401 }
      )
    }

    const clientOfferId = params.id

    // Obtener el client offer con toda la información necesaria
    const clientOffer = await prisma.clientOffer.findUnique({
      where: { id: clientOfferId },
      include: {
        client: true,
        offer: {
          include: {
            provider: true
          }
        }
      }
    })

    if (!clientOffer) {
      return NextResponse.json(
        { error: 'Contrato no encontrado' },
        { status: 404 }
      )
    }

    // Verificar que el usuario sea el cliente o el proveedor
    const isClient = session.user.id === clientOffer.clientId
    const isProvider = session.user.id === clientOffer.offer?.providerId

    if (!isClient && !isProvider) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 403 }
      )
    }

    // Verificar que el contrato esté finalizado
    if (clientOffer.status !== 'COMPLETED') {
      return NextResponse.json(
        { error: 'El contrato no está finalizado' },
        { status: 400 }
      )
    }

    // Verificar que el contrato tenga el documento firmado por el proveedor (el documento final)
    if (!clientOffer.providerSignedDocumentPath) {
      return NextResponse.json(
        { error: 'El contrato final aún no está disponible' },
        { status: 400 }
      )
    }

    // Generar URL firmada para descargar el documento
    const s3Client = createS3Client()
    const bucketName = process.env.AWS_BUCKET_NAME

    if (!bucketName) {
      return NextResponse.json(
        { error: 'Configuración de almacenamiento no disponible' },
        { status: 500 }
      )
    }

    const command = new GetObjectCommand({
      Bucket: bucketName,
      Key: clientOffer.providerSignedDocumentPath,
    })

    const signedUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 })

    return NextResponse.json({
      success: true,
      downloadUrl: signedUrl,
      fileName: `Contrato_Final_${clientOffer.id}.pdf`
    })

  } catch (error) {
    console.error('Error al generar URL de descarga:', error)
    return NextResponse.json(
      { error: 'Error al procesar la descarga' },
      { status: 500 }
    )
  } finally {
    await prisma.$disconnect()
  }
}
