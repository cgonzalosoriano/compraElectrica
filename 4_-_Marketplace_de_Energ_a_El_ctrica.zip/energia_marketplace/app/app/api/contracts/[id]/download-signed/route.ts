
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import { downloadFile } from '@/lib/s3';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const contractId = params.id;
    const { searchParams } = new URL(request.url);
    const party = searchParams.get('party'); // 'client' o 'provider'

    if (!party || (party !== 'client' && party !== 'provider')) {
      return NextResponse.json({ error: 'Parámetro party inválido' }, { status: 400 });
    }

    // Buscar el usuario actual
    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email }
    });

    if (!currentUser) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });
    }

    // Buscar el ClientOffer en lugar de Contract (evita problemas de schema)
    const clientOffer = await prisma.clientOffer.findFirst({
      where: {
        id: contractId,
        OR: [
          { clientId: currentUser.id },
          { offer: { providerId: currentUser.id } }
        ]
      },
      include: {
        client: true,
        offer: {
          include: {
            provider: true
          }
        }
      }
    });

    if (!clientOffer) {
      return NextResponse.json({ error: 'Contrato no encontrado' }, { status: 404 });
    }

    // Obtener el documento firmado correspondiente
    const documentPath = party === 'client' 
      ? clientOffer.clientSignedDocumentPath 
      : clientOffer.providerSignedDocumentPath;

    if (!documentPath) {
      return NextResponse.json({ 
        error: `El ${party === 'client' ? 'cliente' : 'proveedor'} aún no ha subido su documento firmado` 
      }, { status: 404 });
    }

    // Obtener la URL firmada de S3
    const signedUrl = await downloadFile(documentPath);

    // Redirigir a la URL firmada
    return NextResponse.redirect(signedUrl);

  } catch (error) {
    console.error('Error downloading signed contract:', error);
    return NextResponse.json(
      { error: 'Error al descargar el documento: ' + (error as Error).message },
      { status: 500 }
    );
  }
}
