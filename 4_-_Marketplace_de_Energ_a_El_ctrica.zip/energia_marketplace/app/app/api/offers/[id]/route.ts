
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// GET - Obtener una oferta específica
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const offer = await prisma.offer.findUnique({
      where: { 
        id: params.id,
        providerId: session.user.id // Solo puede ver sus propias ofertas
      },
      include: {
        clientOffers: true,
        transactions: true
      }
    });

    if (!offer) {
      return NextResponse.json({ error: 'Oferta no encontrada' }, { status: 404 });
    }

    return NextResponse.json(offer);
  } catch (error) {
    console.error('Error al obtener oferta:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

// PUT - Actualizar una oferta
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.userType !== 'PROVIDER') {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    
    // Verificar que la oferta pertenece al proveedor
    const existingOffer = await prisma.offer.findUnique({
      where: { 
        id: params.id,
        providerId: session.user.id
      }
    });

    if (!existingOffer) {
      return NextResponse.json({ error: 'Oferta no encontrada' }, { status: 404 });
    }

    // Permitir edición incluso con solicitudes aceptadas
    // Las modificaciones solo afectarán nuevas solicitudes, no las existentes

    const updatedOffer = await prisma.offer.update({
      where: { id: params.id },
      data: {
        generationSource: body.generationSource,
        deliveryNode: body.deliveryNode,
        energyPrice: parseFloat(body.energyPrice),
        powerPrice: parseFloat(body.powerPrice || 0),
        availableVolume: parseFloat(body.availableVolume),
        term: parseInt(body.term),
        paymentTerms: body.paymentTerms,
        guarantees: body.guarantees,
        otherConditions: body.otherConditions || null,
        status: body.status || existingOffer.status
      }
    });

    return NextResponse.json({
      message: 'Oferta actualizada exitosamente',
      offer: updatedOffer
    });
  } catch (error) {
    console.error('Error al actualizar oferta:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

// DELETE - Eliminar una oferta
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.userType !== 'PROVIDER') {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    // Verificar que la oferta pertenece al proveedor
    const existingOffer = await prisma.offer.findUnique({
      where: { 
        id: params.id,
        providerId: session.user.id
      },
      include: {
        clientOffers: true
      }
    });

    if (!existingOffer) {
      return NextResponse.json({ error: 'Oferta no encontrada' }, { status: 404 });
    }

    // Eliminar la oferta física del sistema
    // Las solicitudes ya creadas mantienen una copia de las condiciones
    // y pueden continuar su proceso de negociación independientemente
    await prisma.offer.delete({
      where: { id: params.id }
    });

    return NextResponse.json({
      message: 'Oferta eliminada exitosamente. Las solicitudes existentes continuarán con las condiciones originales.'
    });
  } catch (error) {
    console.error('Error al eliminar oferta:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
