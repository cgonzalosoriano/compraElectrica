
import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';

const prisma = new PrismaClient();

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'No autorizado' }, 
        { status: 401 }
      );
    }

    // Verificar que el usuario sea un proveedor
    const user = await prisma.user.findUnique({
      where: { id: session.user.id }
    });

    if (!user || user.userType !== 'PROVIDER') {
      return NextResponse.json(
        { error: 'Solo los proveedores pueden crear ofertas' }, 
        { status: 403 }
      );
    }

    const {
      energyPrice,
      powerPrice,
      term,
      availableVolume,
      deliveryNode,
      paymentMethods,
      requiredGuarantees,
      generationSource,
      additionalConditions
    } = await request.json();

    // Validaciones básicas
    if (!energyPrice || !powerPrice || !term || !availableVolume || 
        !deliveryNode || !paymentMethods || !requiredGuarantees || !generationSource) {
      return NextResponse.json(
        { error: 'Faltan campos requeridos' }, 
        { status: 400 }
      );
    }

    // Crear la oferta
    const offer = await prisma.offer.create({
      data: {
        providerId: session.user.id,
        energyPrice: parseFloat(energyPrice),
        powerPrice: parseFloat(powerPrice),
        term: parseInt(term),
        availableVolume: parseFloat(availableVolume),
        deliveryNode,
        paymentTerms: paymentMethods,
        guarantees: requiredGuarantees,
        generationSource,
        otherConditions: additionalConditions || '',
        status: 'ACTIVE'
      }
    });

    return NextResponse.json(
      { 
        message: 'Oferta creada exitosamente', 
        offer: {
          id: offer.id,
          energyPrice: offer.energyPrice,
          powerPrice: offer.powerPrice,
          term: offer.term,
          availableVolume: offer.availableVolume,
          generationSource: offer.generationSource,
          deliveryNode: offer.deliveryNode,
          status: offer.status
        }
      }, 
      { status: 201 }
    );

  } catch (error) {
    console.error('Error creating offer:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' }, 
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const providerId = searchParams.get('providerId');

    let whereClause: any = { status: 'ACTIVE' };
    
    if (providerId) {
      whereClause.providerId = providerId;
    }

    const offers = await prisma.offer.findMany({
      where: whereClause,
      include: {
        provider: {
          select: {
            id: true,
            companyName: true,
            name: true
          }
        },
        clientOffers: {
          where: { status: 'PENDING' },
          include: {
            client: {
              select: {
                id: true,
                companyName: true,
                name: true
              }
            }
          }
        },
        _count: {
          select: {
            clientOffers: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json({ offers });

  } catch (error) {
    console.error('Error fetching offers:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' }, 
      { status: 500 }
    );
  }
}
