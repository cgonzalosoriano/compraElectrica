
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { PrismaClient } from '@prisma/client'
import ProviderDashboard from '@/components/provider/provider-dashboard'

const prisma = new PrismaClient()

export default async function ProviderPage() {
  const session = await getServerSession(authOptions)
  
  if (!session) {
    redirect('/auth/signin')
  }

  if (session.user.userType !== 'PROVIDER') {
    redirect('/')
  }

  // Obtener datos del proveedor
  const provider = await prisma.user.findUnique({
    where: { id: session.user.id },
    include: {
      offers: {
        include: {
          clientOffers: {
            include: {
              client: true
            }
          },
          transactions: true
        },
        orderBy: { createdAt: 'desc' }
      },
      // Incluir contratos donde el proveedor está involucrado (contratos de cotizaciones)
      providerQuoteContracts: {
        include: {
          client: true,
          quoteResponse: true,
          quoteRequest: true
        },
        orderBy: { createdAt: 'desc' }
      }
    }
  })

  if (!provider) {
    redirect('/auth/signin')
  }

  return <ProviderDashboard provider={provider} />
}
