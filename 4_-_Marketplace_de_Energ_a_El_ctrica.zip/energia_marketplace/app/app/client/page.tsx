
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { PrismaClient } from '@prisma/client'
import ClientDashboard from '@/components/client/client-dashboard'

const prisma = new PrismaClient()

export default async function ClientPage() {
  const session = await getServerSession(authOptions)
  
  if (!session) {
    redirect('/auth/signin')
  }

  if (session.user.userType !== 'CLIENT') {
    redirect('/')
  }

  // Obtener datos del cliente
  const client = await prisma.user.findUnique({
    where: { id: session.user.id },
    include: {
      clientOffers: {
        include: {
          offer: {
            include: {
              provider: true
            }
          }
        },
        orderBy: { createdAt: 'desc' }
      },
      transactions: {
        include: {
          offer: true
        },
        orderBy: { createdAt: 'desc' }
      }
    }
  })

  if (!client) {
    redirect('/auth/signin')
  }

  // Obtener contratos de cotizaciones (QuoteContract)
  const contracts = await prisma.quoteContract.findMany({
    where: {
      clientId: session.user.id
    },
    include: {
      provider: true,
      quoteResponse: true,
      quoteRequest: true
    },
    orderBy: { createdAt: 'desc' }
  })

  // Obtener ofertas activas disponibles
  const availableOffers = await prisma.offer.findMany({
    where: {
      status: 'ACTIVE'
    },
    include: {
      provider: true
    },
    orderBy: { createdAt: 'desc' }
  })

  return (
    <ClientDashboard 
      client={client} 
      contracts={contracts}
      availableOffers={availableOffers}
    />
  )
}
