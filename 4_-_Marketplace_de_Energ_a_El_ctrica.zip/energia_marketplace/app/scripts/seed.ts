
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Iniciando semilla de datos...');

  // Hash para contraseñas
  const hashedPassword = await bcrypt.hash('password123', 10);
  const hashedAdminPassword = await bcrypt.hash('admin123', 10);
  const hashedTestPassword = await bcrypt.hash('johndoe123', 10);

  // 1. Crear usuarios administradores
  const admin = await prisma.user.create({
    data: {
      email: 'admin@energiamarket.com.ar',
      password: hashedAdminPassword,
      name: 'Administrador Sistema',
      companyName: 'EnergiaMarket Argentina',
      phone: '+54 11 5555-0000',
      userType: 'ADMIN',
      cuit: '30-12345678-9',
      isKycVerified: true,
      address: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      province: 'Ciudad Autónoma de Buenos Aires',
      postalCode: 'C1043AAZ'
    }
  });

  // Usuario de prueba requerido
  const testUser = await prisma.user.create({
    data: {
      email: 'john@doe.com',
      password: hashedTestPassword,
      name: 'John Doe',
      companyName: 'Test Company',
      phone: '+54 11 9999-9999',
      userType: 'ADMIN',
      cuit: '20-99999999-9',
      isKycVerified: true,
    }
  });

  // 2. Crear proveedores de energía
  const proveedor1 = await prisma.user.create({
    data: {
      email: 'comercial@energiarenovable.com.ar',
      password: hashedPassword,
      name: 'Carlos Energético',
      companyName: 'Energía Renovable SA',
      phone: '+54 11 4444-1111',
      userType: 'PROVIDER',
      cuit: '30-11111111-9',
      isKycVerified: true,
      address: 'Av. del Libertador 5555',
      city: 'Buenos Aires',
      province: 'Ciudad Autónoma de Buenos Aires',
      postalCode: 'C1426ABC'
    }
  });

  const proveedor2 = await prisma.user.create({
    data: {
      email: 'ventas@generadorasolar.com',
      password: hashedPassword,
      name: 'María Solariza',
      companyName: 'Generadora Solar del Sur',
      phone: '+54 351 555-2222',
      userType: 'PROVIDER',
      cuit: '30-22222222-9',
      isKycVerified: true,
      address: 'Bv. San Juan 2000',
      city: 'Córdoba',
      province: 'Córdoba',
      postalCode: 'X5000AAA'
    }
  });

  const proveedor3 = await prisma.user.create({
    data: {
      email: 'contacto@eolicapatagonia.com.ar',
      password: hashedPassword,
      name: 'Roberto Vientos',
      companyName: 'Eólica Patagonia SRL',
      phone: '+54 2944 33-3333',
      userType: 'PROVIDER',
      cuit: '30-33333333-9',
      isKycVerified: true,
      address: 'Ruta 22 Km 1200',
      city: 'Neuquén',
      province: 'Neuquén',
      postalCode: 'Q8300AAA'
    }
  });

  // 3. Crear clientes comerciales/industriales
  const cliente1 = await prisma.user.create({
    data: {
      email: 'compras@metalurgicasur.com.ar',
      password: hashedPassword,
      name: 'Ana Industria',
      companyName: 'Metalúrgica del Sur SA',
      phone: '+54 11 2222-3333',
      userType: 'CLIENT',
      cuit: '30-44444444-9',
      isKycVerified: true,
      address: 'Parque Industrial Pilar, Lote 45',
      city: 'Pilar',
      province: 'Buenos Aires',
      postalCode: 'B1629AAA',
      distributorName: 'EDESUR',
      region: 'Zona Norte',
      tariffType: 'TM1',
      contractedPower: 500.0,
      userNumber: 'ED001234567'
    }
  });

  const cliente2 = await prisma.user.create({
    data: {
      email: 'energia@textilrosario.com',
      password: hashedPassword,
      name: 'Luis Fabricante',
      companyName: 'Textil Rosario SRL',
      phone: '+54 341 444-5555',
      userType: 'CLIENT',
      cuit: '30-55555555-9',
      isKycVerified: true,
      address: 'Zona Industrial Norte, Manzana 12',
      city: 'Rosario',
      province: 'Santa Fe',
      postalCode: 'S2000AAA',
      distributorName: 'EPE',
      region: 'Gran Rosario',
      tariffType: 'TM2',
      contractedPower: 250.0,
      userNumber: 'EP987654321'
    }
  });

  const cliente3 = await prisma.user.create({
    data: {
      email: 'administracion@supermercadocentral.com.ar',
      password: hashedPassword,
      name: 'Sofía Comercio',
      companyName: 'Supermercado Central SA',
      phone: '+54 261 666-7777',
      userType: 'CLIENT',
      cuit: '30-66666666-9',
      isKycVerified: true,
      address: 'Av. San Martín 8888',
      city: 'Mendoza',
      province: 'Mendoza',
      postalCode: 'M5500AAA',
      distributorName: 'EDEMSA',
      region: 'Gran Mendoza',
      tariffType: 'TM1',
      contractedPower: 150.0,
      userNumber: 'EM123456789'
    }
  });

  console.log('👥 Usuarios creados');

  // 4. Crear ofertas de energía
  const oferta1 = await prisma.offer.create({
    data: {
      providerId: proveedor1.id,
      energyPrice: 45.50,
      powerPrice: 1200.00,
      term: 12,
      availableVolume: 10000.0,
      deliveryNode: 'Nodo Buenos Aires',
      paymentTerms: 'Transferencia bancaria - 30 días',
      guarantees: 'Garantía bancaria 10% del monto total',
      generationSource: 'Energía Solar Fotovoltaica',
      otherConditions: 'Contrato mínimo 6 meses. Precios fijos durante el plazo.',
      status: 'ACTIVE'
    }
  });

  const oferta2 = await prisma.offer.create({
    data: {
      providerId: proveedor2.id,
      energyPrice: 42.80,
      powerPrice: 1150.00,
      term: 24,
      availableVolume: 15000.0,
      deliveryNode: 'Nodo Córdoba',
      paymentTerms: 'Transferencia bancaria - 15 días',
      guarantees: 'Seguro de caución 8% del monto',
      generationSource: 'Energía Solar con Respaldo',
      otherConditions: 'Descuento por volumen >5000 MWh. Indexación semestral.',
      status: 'ACTIVE'
    }
  });

  const oferta3 = await prisma.offer.create({
    data: {
      providerId: proveedor3.id,
      energyPrice: 38.90,
      powerPrice: 980.00,
      term: 36,
      availableVolume: 25000.0,
      deliveryNode: 'Nodo Patagonia',
      paymentTerms: 'Transferencia bancaria - 45 días',
      guarantees: 'Pagaré avalado 5% del monto',
      generationSource: 'Energía Eólica',
      otherConditions: 'Precio especial por contratos >2 años. Factor de potencia >0.95 requerido.',
      status: 'ACTIVE'
    }
  });

  const oferta4 = await prisma.offer.create({
    data: {
      providerId: proveedor1.id,
      energyPrice: 48.20,
      powerPrice: 1350.00,
      term: 6,
      availableVolume: 5000.0,
      deliveryNode: 'Nodo Capital Federal',
      paymentTerms: 'Transferencia bancaria - 7 días',
      guarantees: 'Garantía a primera demanda 15%',
      generationSource: 'Mix Renovable (Solar + Eólica)',
      otherConditions: 'Ideal para prueba piloto. Flexibilidad de volúmenes.',
      status: 'ACTIVE'
    }
  });

  console.log('⚡ Ofertas de energía creadas');

  // 5. Crear algunas interacciones de clientes con ofertas
  const clientOffer1 = await prisma.clientOffer.create({
    data: {
      offerId: oferta1.id,
      clientId: cliente1.id,
      userNumber: cliente1.userNumber!,
      distributorName: cliente1.distributorName!,
      region: cliente1.region!,
      address: cliente1.address!,
      tariffType: cliente1.tariffType!,
      requestedVolume: 2500.0,
      status: 'PENDING'
    }
  });

  const clientOffer2 = await prisma.clientOffer.create({
    data: {
      offerId: oferta2.id,
      clientId: cliente2.id,
      userNumber: cliente2.userNumber!,
      distributorName: cliente2.distributorName!,
      region: cliente2.region!,
      address: cliente2.address!,
      tariffType: cliente2.tariffType!,
      requestedVolume: 1800.0,
      status: 'ACCEPTED'
    }
  });

  // 6. Crear una transacción de ejemplo
  const transaction1 = await prisma.transaction.create({
    data: {
      offerId: oferta2.id,
      clientOfferId: clientOffer2.id,
      clientId: cliente2.id,
      providerId: proveedor2.id,
      agreedEnergyPrice: 42.80,
      agreedPowerPrice: 1150.00,
      agreedVolume: 1800.0,
      totalAmount: 77040.0, // 42.80 * 1800
      commissionAmount: 1540.80, // 2% de 77040
      status: 'NEGOTIATING'
    }
  });

  // 7. Crear algunos mensajes de ejemplo
  await prisma.message.create({
    data: {
      senderId: cliente2.id,
      recipientId: proveedor2.id,
      transactionId: transaction1.id,
      subject: 'Consulta sobre condiciones de pago',
      content: 'Estimados, necesitaría conocer si es posible extender el plazo de pago a 30 días dado nuestro ciclo de cobranzas. Quedamos a la espera de su respuesta.',
      messageType: 'NEGOTIATION'
    }
  });

  await prisma.message.create({
    data: {
      senderId: proveedor2.id,
      recipientId: cliente2.id,
      transactionId: transaction1.id,
      subject: 'Re: Consulta sobre condiciones de pago',
      content: 'Estimado Luis, gracias por su consulta. Podemos considerar 30 días de plazo manteniendo las demás condiciones. ¿Le parece que agendemos una llamada para definir los detalles finales?',
      messageType: 'NEGOTIATION',
      isRead: false
    }
  });

  // 8. Crear un documento de ejemplo
  await prisma.document.create({
    data: {
      userId: cliente1.id,
      name: 'Poder General de Administración',
      documentType: 'LEGAL_POWER',
      cloudStoragePath: '/documents/legal/poder_general_metalurgica_sur.pdf',
      status: 'APPROVED'
    }
  });

  console.log('📄 Documentos y mensajes de ejemplo creados');
  
  console.log(`
  🎉 Semilla completada exitosamente!
  
  👤 Usuarios creados:
  - Admin: admin@energiamarket.com.ar (password: admin123)
  - Test: john@doe.com (password: johndoe123)
  - Proveedores: 3 empresas generadoras
  - Clientes: 3 empresas consumidoras
  
  ⚡ Ofertas disponibles: 4
  📊 Transacciones en curso: 1
  💬 Mensajes de negociación: 2
  📄 Documentos cargados: 1
  `);
}

main()
  .catch((e) => {
    console.error('Error durante la semilla:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
