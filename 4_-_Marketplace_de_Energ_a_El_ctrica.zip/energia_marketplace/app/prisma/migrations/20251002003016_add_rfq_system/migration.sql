-- CreateEnum
CREATE TYPE "QuoteRequestStatus" AS ENUM ('ACTIVE', 'CLOSED', 'EXPIRED', 'AWARDED');

-- CreateEnum
CREATE TYPE "QuoteResponseStatus" AS ENUM ('DRAFT', 'SUBMITTED', 'UPDATED', 'ACCEPTED', 'REJECTED', 'WITHDRAWN');

-- CreateEnum
CREATE TYPE "NotificationType" AS ENUM ('NEW_QUOTE_REQUEST', 'NEW_QUOTE_RESPONSE', 'QUOTE_RESPONSE_UPDATED', 'QUOTE_REQUEST_CLOSING_SOON', 'QUOTE_REQUEST_EXPIRED', 'QUOTE_REQUEST_CLOSED', 'QUOTE_RESPONSE_ACCEPTED', 'QUOTE_RESPONSE_REJECTED', 'CONTRACT_UPDATE');

-- CreateTable
CREATE TABLE "QuoteRequest" (
    "id" TEXT NOT NULL,
    "clientId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "termMonths" INTEGER NOT NULL,
    "startDate" TIMESTAMP(3),
    "paymentTerms" TEXT,
    "guaranteesOffered" TEXT,
    "preferredEnergySource" TEXT,
    "deliveryNode" TEXT,
    "userNumber" TEXT,
    "distributorName" TEXT,
    "region" TEXT,
    "deadline" TIMESTAMP(3) NOT NULL,
    "status" "QuoteRequestStatus" NOT NULL DEFAULT 'ACTIVE',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "QuoteRequest_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "QuoteRequestPeriod" (
    "id" TEXT NOT NULL,
    "quoteRequestId" TEXT NOT NULL,
    "periodNumber" INTEGER NOT NULL,
    "periodName" TEXT NOT NULL,
    "powerKW" DOUBLE PRECISION,
    "energyMWh" DOUBLE PRECISION,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "QuoteRequestPeriod_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "QuoteRequestClause" (
    "id" TEXT NOT NULL,
    "quoteRequestId" TEXT NOT NULL,
    "clauseName" TEXT NOT NULL,
    "clauseDescription" TEXT NOT NULL,
    "isRequired" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "QuoteRequestClause_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "QuoteResponse" (
    "id" TEXT NOT NULL,
    "quoteRequestId" TEXT NOT NULL,
    "providerId" TEXT NOT NULL,
    "energyPricePerMWh" DOUBLE PRECISION,
    "powerPricePerKW" DOUBLE PRECISION,
    "paymentTerms" TEXT,
    "guaranteesRequired" TEXT,
    "deliveryNode" TEXT,
    "generationSource" TEXT,
    "otherConditions" TEXT,
    "totalEstimated" DOUBLE PRECISION,
    "providerComments" TEXT,
    "status" "QuoteResponseStatus" NOT NULL DEFAULT 'SUBMITTED',
    "viewedByClient" BOOLEAN NOT NULL DEFAULT false,
    "viewedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "QuoteResponse_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "QuoteResponsePeriod" (
    "id" TEXT NOT NULL,
    "quoteResponseId" TEXT NOT NULL,
    "periodNumber" INTEGER NOT NULL,
    "periodName" TEXT NOT NULL,
    "energyPricePerMWh" DOUBLE PRECISION,
    "powerPricePerKW" DOUBLE PRECISION,
    "availablePowerKW" DOUBLE PRECISION,
    "availableEnergyMWh" DOUBLE PRECISION,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "QuoteResponsePeriod_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Notification" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "type" "NotificationType" NOT NULL,
    "title" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "quoteRequestId" TEXT,
    "quoteResponseId" TEXT,
    "contractId" TEXT,
    "isRead" BOOLEAN NOT NULL DEFAULT false,
    "readAt" TIMESTAMP(3),
    "actionUrl" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Notification_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "QuoteRequestPeriod_quoteRequestId_periodNumber_key" ON "QuoteRequestPeriod"("quoteRequestId", "periodNumber");

-- CreateIndex
CREATE UNIQUE INDEX "QuoteResponse_quoteRequestId_providerId_key" ON "QuoteResponse"("quoteRequestId", "providerId");

-- CreateIndex
CREATE UNIQUE INDEX "QuoteResponsePeriod_quoteResponseId_periodNumber_key" ON "QuoteResponsePeriod"("quoteResponseId", "periodNumber");

-- CreateIndex
CREATE INDEX "Notification_userId_isRead_idx" ON "Notification"("userId", "isRead");

-- AddForeignKey
ALTER TABLE "QuoteRequest" ADD CONSTRAINT "QuoteRequest_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "QuoteRequestPeriod" ADD CONSTRAINT "QuoteRequestPeriod_quoteRequestId_fkey" FOREIGN KEY ("quoteRequestId") REFERENCES "QuoteRequest"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "QuoteRequestClause" ADD CONSTRAINT "QuoteRequestClause_quoteRequestId_fkey" FOREIGN KEY ("quoteRequestId") REFERENCES "QuoteRequest"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "QuoteResponse" ADD CONSTRAINT "QuoteResponse_quoteRequestId_fkey" FOREIGN KEY ("quoteRequestId") REFERENCES "QuoteRequest"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "QuoteResponse" ADD CONSTRAINT "QuoteResponse_providerId_fkey" FOREIGN KEY ("providerId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "QuoteResponsePeriod" ADD CONSTRAINT "QuoteResponsePeriod_quoteResponseId_fkey" FOREIGN KEY ("quoteResponseId") REFERENCES "QuoteResponse"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Notification" ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Notification" ADD CONSTRAINT "Notification_quoteRequestId_fkey" FOREIGN KEY ("quoteRequestId") REFERENCES "QuoteRequest"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Notification" ADD CONSTRAINT "Notification_quoteResponseId_fkey" FOREIGN KEY ("quoteResponseId") REFERENCES "QuoteResponse"("id") ON DELETE CASCADE ON UPDATE CASCADE;
