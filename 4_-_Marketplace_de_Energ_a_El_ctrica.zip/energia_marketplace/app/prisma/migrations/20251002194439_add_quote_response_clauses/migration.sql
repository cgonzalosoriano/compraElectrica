-- CreateEnum
CREATE TYPE "ClauseAction" AS ENUM ('ACCEPT', 'NEGOTIATE');

-- CreateTable
CREATE TABLE "QuoteResponseClause" (
    "id" TEXT NOT NULL,
    "quoteResponseId" TEXT NOT NULL,
    "clauseId" TEXT NOT NULL,
    "action" "ClauseAction" NOT NULL,
    "negotiation" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "QuoteResponseClause_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "QuoteResponseClause_quoteResponseId_clauseId_key" ON "QuoteResponseClause"("quoteResponseId", "clauseId");

-- AddForeignKey
ALTER TABLE "QuoteResponseClause" ADD CONSTRAINT "QuoteResponseClause_quoteResponseId_fkey" FOREIGN KEY ("quoteResponseId") REFERENCES "QuoteResponse"("id") ON DELETE CASCADE ON UPDATE CASCADE;
