-- AlterTable
ALTER TABLE "ClientOffer" ADD COLUMN     "clientSignedAt" TIMESTAMP(3),
ADD COLUMN     "clientSignedDocumentPath" TEXT,
ADD COLUMN     "providerSignedAt" TIMESTAMP(3),
ADD COLUMN     "providerSignedDocumentPath" TEXT;
